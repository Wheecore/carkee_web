@extends('frontend.layouts.app')
@section('title', 'Home')
@section('content')
<link rel="stylesheet" href="{{ static_asset('assets/css/test.css') }}">

<main class="bg-white">
    <div class="drawer-backdrop  js-mobile-menu-toggle"></div>
    <div class="header__finder  flex__left-auto  text--uppercase  weight--semibold  hidden">
        <a href="#js-mobile-sort__trigger" class="text--white  js-mobile-sort__trigger">Sort</a>
        <a href="#js-mobile-show-search" class="text--white  js-mobile-show-search">Search</a>
    </div>
    <nav class="drawer  drawer--site  transition--default  visuallyhidden--desk  js-mobile-menu">
        <div class="drawer__header">
            <a href="javascript:void(0)" class="drawer__dismiss  js-mobile-menu-toggle"><i class="icon  icon--md-close"></i></a>

            <ul class="drawer__menu  drawer__menu--access  text--center  list--reset  hard--top">
                <li class="flex">
                    <a href="/" class="one-half  js-loginbtn" data-auth="login">Sign In</a>
                    <a href="/" class="one-half  js-signupbtn" data-auth="signup">Register (Private)</a>
                </li>
                <li>
                    <a href="https://accounts.icarsuite.com/register?project=carlist&amp;lang=en" target="_blank">
                        Register as Dealer / Agent                        <small class="text--muted">For Businesses and Sales Agents</small>
                    </a>
                </li>
            </ul>
        </div>
        {{--<ul class="drawer__menu  drawer__menu--site  fill--white  list--reset">--}}
            {{--<li><a href="https://www.carlist.my" class="drawer__link">Home</a></li>--}}
            {{--<li>--}}
                {{--<input id="option--Buy" type="checkbox" class="collapsible__target  visuallyhidden">--}}
                {{--<label for="option--Buy" class="drawer__link  collapsible__control">--}}
                    {{--<span>Buy</span>--}}
                    {{--<span class="chevron  icon  icon--down-open  text--muted  transition--default  flex__left-auto"></span>--}}
                {{--</label>--}}
                {{--<div class="collapsible__container">--}}
                    {{--<ul class="drawer__submenu  list--reset">--}}
                        {{--<li class="drawer__subtitle  text--muted  text--uppercase">Cars for sale</li>--}}
                        {{--<li>--}}
                            {{--<a href="https://www.carlist.my/used-cars-for-sale/malaysia">Used Cars</a></li>--}}
                        {{--<li>--}}
                            {{--<a href="https://www.carlist.my/new-cars-for-sale/malaysia">New Cars</a></li>--}}
                        {{--<li>--}}
                            {{--<a href="https://www.carlist.my/recon-cars-for-sale/malaysia">Recon Cars</a></li>--}}
                        {{--<li>--}}
                            {{--<a href="https://www.carlist.my/kereta-murah">Kereta Murah</a></li>--}}
                        {{--<li>--}}
                            {{--<a href="/cars-for-sale/malaysia?hotdeal=true"><span class="icon  icon--flexible  icon--fire  push-half--right  u-margin-right-sm  icon--16  icon--product-hotdeal"></span>Hot Deals</a></li>--}}
                    {{--</ul>--}}
                    {{--<ul class="drawer__submenu  list--reset">--}}
                        {{--<li class="drawer__subtitle  text--muted  text--uppercase">Carlist.my Services</li>--}}
                        {{--<li>--}}
                            {{--<a href="https://www.carlist.my/form/carlist360" target="_blank"><span>Carlist.my 360</span><span class="pill  pill--green  milli  push-half--left  soft-half--sides  c-chip  c-chip--xs  c-chip--green-inverted  u-margin-left-xs">NEW</span></a></li>--}}
                    {{--</ul>--}}
                    {{--<ul class="drawer__submenu  list--reset">--}}
                        {{--<li class="drawer__subtitle  text--muted  text--uppercase">Certified Pre-owned</li>--}}
                        {{--<li>--}}
                            {{--<a href="/cars-for-sale/malaysia?bmw=true" target="_blank"><span class="icon  icon--flexible  push-quarter--right  u-margin-right-sm  icon--16 icon-bmw"></span><span>BMW Premium Selection</span></a></li>--}}
                        {{--<li>--}}
                            {{--<a href="/cars-for-sale/malaysia?volvo=true" target="_blank"><span class="icon  icon--flexible  push-quarter--right  u-margin-right-sm  icon--16 icon-volvo"></span><span>Volvo Quality Used Cars</span></a></li>--}}
                    {{--</ul>--}}
                {{--</div>--}}
            {{--</li>--}}
            {{--<li>--}}
                {{--<input id="option--Sell" type="checkbox" class="collapsible__target  visuallyhidden">--}}
                {{--<label for="option--Sell" class="drawer__link  collapsible__control">--}}
                    {{--<span>Sell</span>--}}
                    {{--<span class="chevron  icon  icon--down-open  text--muted  transition--default  flex__left-auto"></span>--}}
                {{--</label>--}}
                {{--<div class="collapsible__container">--}}
                    {{--<ul class="drawer__submenu  list--reset">--}}
                        {{--<li class="drawer__subtitle  text--muted  text--uppercase">Sell Your Car</li>--}}
                        {{--<li>--}}
                            {{--<a href="https://www.carlist.my/account/listing/create-selection"><span>Create Ad</span><span class="pill  milli  push-half--left  soft-half--sides  c-chip  c-chip--xs  c-chip--red-inverted  u-margin-left-sm">FREE</span></a></li>--}}
                        {{--<li>--}}
                            {{--<a href="https://www.carlist.my/faq#selling">How to sell your car</a></li>--}}
                    {{--</ul>--}}
                    {{--<ul class="drawer__submenu  list--reset">--}}
                        {{--<li class="drawer__subtitle  text--muted  text--uppercase">Car Selling Services</li>--}}
                        {{--<li>--}}
                            {{--<a href="https://bid.carlist.my/" target="_blank"><span>CarlistBid.my</span><span class="pill  pill--green  milli  push-half--left  soft-half--sides  c-chip  c-chip--xs  c-chip--green-inverted  u-margin-left-sm">NEW</span></a></li>--}}
                    {{--</ul>--}}
                {{--</div>--}}
            {{--</li>--}}
            {{--<li>--}}
                {{--<input id="option--New Cars" type="checkbox" class="collapsible__target  visuallyhidden">--}}
                {{--<label for="option--New Cars" class="drawer__link  collapsible__control">--}}
                    {{--<span>New Cars</span>--}}
                    {{--<span class="chevron  icon  icon--down-open  text--muted  transition--default  flex__left-auto"></span>--}}
                {{--</label>--}}
                {{--<div class="collapsible__container">--}}
                    {{--<ul class="drawer__submenu  list--reset">--}}
                        {{--<li>--}}
                            {{--<a href="https://newcar.carlist.my" target="_blank"><span>New Car Deals</span><span class="pill  pill--green  milli  push-half--left  soft-half--sides  c-chip  c-chip--xs  c-chip--green-inverted  u-margin-left-sm">NEW</span></a></li>--}}
                        {{--<li>--}}
                            {{--<a href="https://www.carlist.my/new-car/price-list" target="_blank">New Car Price List</a></li>--}}
                    {{--</ul>--}}
                {{--</div>--}}
            {{--</li>--}}
            {{--<li>--}}
                {{--<input id="option--Finance" type="checkbox" class="collapsible__target  visuallyhidden">--}}
                {{--<label for="option--Finance" class="drawer__link  collapsible__control">--}}
                    {{--<span>Finance</span>--}}
                    {{--<span class="chevron  icon  icon--down-open  text--muted  transition--default  flex__left-auto"></span>--}}
                {{--</label>--}}
                {{--<div class="collapsible__container">--}}
                    {{--<ul class="drawer__submenu  list--reset">--}}
                        {{--<li>--}}
                            {{--<a href="/finance">Car Loan</a></li>--}}
                        {{--<li>--}}
                            {{--<a href="/insurance">Car Insurance</a></li>--}}
                        {{--<li>--}}
                            {{--<a href="/extended-warranty">Extended Warranty</a></li>--}}
                    {{--</ul>--}}
                {{--</div>--}}
            {{--</li>--}}
            {{--<li>--}}
                {{--<input id="option--News" type="checkbox" class="collapsible__target  visuallyhidden">--}}
                {{--<label for="option--News" class="drawer__link  collapsible__control">--}}
                    {{--<span>News</span>--}}
                    {{--<span class="chevron  icon  icon--down-open  text--muted  transition--default  flex__left-auto"></span>--}}
                {{--</label>--}}
                {{--<div class="collapsible__container">--}}
                    {{--<ul class="drawer__submenu  list--reset">--}}
                        {{--<li>--}}
                            {{--<a href="https://www.carlist.my/news/">All News</a></li>--}}
                        {{--<li>--}}
                            {{--<a href="https://www.carlist.my/news/auto-news/">Auto News</a></li>--}}
                        {{--<li>--}}
                            {{--<a href="https://www.carlist.my/news/insights/">Insights</a></li>--}}
                        {{--<li>--}}
                            {{--<a href="https://www.carlist.my/news/reviews/">Reviews</a></li>--}}
                        {{--<li>--}}
                            {{--<a href="https://www.carlist.my/news/buying-guide/">Buying Guide</a></li>--}}
                        {{--<li>--}}
                            {{--<a href="https://www.carlist.my/news/live-life-drive/">Live Life Drive</a></li>--}}
                        {{--<li>--}}
                            {{--<a href="https://www.carlist.my/news/photos/">Photos</a></li>--}}
                        {{--<li>--}}
                            {{--<a href="https://www.carlist.my/news/videos/">Videos</a></li>--}}
                    {{--</ul>--}}
                {{--</div>--}}
            {{--</li>--}}
            {{--<li>--}}
                {{--<input id="option--Events" type="checkbox" class="collapsible__target  visuallyhidden">--}}
                {{--<label for="option--Events" class="drawer__link  collapsible__control">--}}
                    {{--<span>Events</span>--}}
                    {{--<span class="chevron  icon  icon--down-open  text--muted  transition--default  flex__left-auto"></span>--}}
                {{--</label>--}}
                {{--<div class="collapsible__container">--}}
                    {{--<ul class="drawer__submenu  list--reset">--}}
                        {{--<li class="drawer__subtitle  text--muted  text--uppercase">Event Services</li>--}}
                        {{--<li>--}}
                            {{--<a href="/event/services" target="_blank">Hire us!</a></li>--}}
                        {{--<li>--}}
                            {{--<a href="/event/services/#contact" target="_blank">Become a Partner</a></li>--}}
                    {{--</ul>--}}
                    {{--<ul class="drawer__submenu  list--reset">--}}
                        {{--<li class="drawer__subtitle  text--muted  text--uppercase">Past Events</li>--}}
                        {{--<li>--}}
                            {{--<a href="https://www.carlist.my/events">View All Past Events</a></li>--}}
                    {{--</ul>--}}
                {{--</div>--}}
            {{--</li>--}}
        {{--</ul>--}}
        {{--<ul class="drawer__menu  drawer__menu--extra  list--reset">--}}
            {{--<li>--}}
                {{--<input id="option--Language" type="checkbox" class="collapsible__target  visuallyhidden">--}}
                {{--<label for="option--Language" class="drawer__link  collapsible__control">--}}
                    {{--<span>Language</span>--}}
                    {{--<span class="flex  flex__left-auto">--}}
            {{--<span class="soft-quarter--right  text--link" lang="EN">EN</span>--}}
            {{--<span class="chevron  icon  icon--down-open  text--muted  transition--default"></span>--}}
        {{--</span>--}}
                {{--</label>--}}
                {{--<div class="collapsible__container">--}}
                    {{--<ul class="drawer__submenu  list--reset  flush--top">--}}
                        {{--<li>--}}
                            {{--<a lang="en" href="https://www.carlist.my/cars-for-sale/toyota/86/malaysia" class="flex  flex--items-center  flex--justify-between  js-part-language-switcher  js-part-language-switcher--en  is--active">--}}
                                {{--<span>English</span>--}}
                                {{--<span class="icon  icon--md-done"></span>--}}
                            {{--</a>--}}
                        {{--</li>--}}
                        {{--<li>--}}
                            {{--<a lang="ms" href="https://www.carlist.my/ms/kereta-untuk-dijual/toyota/86/malaysia" class="flex  flex--items-center  flex--justify-between  js-part-language-switcher  js-part-language-switcher--ms  ">--}}
                                {{--<span>Bahasa Malaysia</span>--}}
                                {{--<span class="icon  icon--md-done  visuallyhidden"></span>--}}
                            {{--</a>--}}
                        {{--</li>--}}
                        {{--<li>--}}
                            {{--<a lang="zh" href="https://www.carlist.my/zh/cars-for-sale/toyota/86/malaysia" class="flex  flex--items-center  flex--justify-between  js-part-language-switcher  js-part-language-switcher--zh  ">--}}
                                {{--<span>中文</span>--}}
                                {{--<span class="icon  icon--md-done  visuallyhidden"></span>--}}
                            {{--</a>--}}
                        {{--</li>--}}
                    {{--</ul>--}}
                {{--</div>--}}
            {{--</li>--}}
           {{----}}
        {{--</ul>--}}
    </nav>

    <div id="classified-listings" class="listings  relative  ">
        <div class="container  container--listing  cf">

            <ol itemscope="" itemtype="http://schema.org/BreadcrumbList" class="breadcrumb  breadcrumb--site  nav  milli  breadcrumb--listing  push--top  push--bottom  visuallyhidden--portable  push--top  push--bottom  js-part-breadcrumb  visuallyhidden--portable">
                {{--<li class="" itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">--}}
                    {{--<a itemprop="item" href="/">--}}
                        {{--<span itemprop="name">Home</span>--}}
                        {{--<meta itemprop="position" content="1">--}}
                    {{--</a>--}}
                {{--</li>--}}
                {{--<li class="js-ajax-links" itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">--}}
                    {{--<a itemprop="item" href="https://www.carlist.my/cars-for-sale/toyota/86/malaysia">--}}
                        {{--<span itemprop="name">Cars</span>--}}
                        {{--<meta itemprop="position" content="2">--}}
                    {{--</a>--}}
                {{--</li>--}}
                {{--<li class="js-ajax-links" itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">--}}
                    {{--<a itemprop="item" href="https://www.carlist.my/cars-for-sale/toyota/86/malaysia">--}}
                        {{--<span itemprop="name">Toyota</span>--}}
                        {{--<meta itemprop="position" content="3">--}}
                    {{--</a>--}}
                {{--</li>--}}
                {{--<li class="js-ajax-links" itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">--}}
                    {{--<a itemprop="item" href="https://www.carlist.my/cars-for-sale/toyota/86/malaysia">--}}
                        {{--<span itemprop="name">86</span>--}}
                        {{--<meta itemprop="position" content="4">--}}
                    {{--</a>--}}
                {{--</li>--}}
            </ol>
            <div class="grid  grid--classified">
                <nav class="listings__fixed-left  grid__item  js-listings__fixed-left  js-listings__fixed-left--sticky-top  js-part-facets">



                    <div class="smenu  box  hard  fixed  transition--default" data-smenu-params="{&quot;make&quot;:&quot;toyota&quot;,&quot;model&quot;:&quot;86&quot;,&quot;vehicle_type&quot;:&quot;car&quot;,&quot;badge_operator&quot;:&quot;OR&quot;,&quot;boss&quot;:true,&quot;page_size&quot;:25,&quot;facets_all&quot;:true,&quot;page_number&quot;:1,&quot;total&quot;:504}" style="-webkit-box-sizing: border-box; box-sizing: border-box; background: #fff; border-radius: 4px; -webkit-box-shadow: 0 2px 4px rgba(52, 66, 81, .1), 0 0 0 1px rgba(52, 66, 81, .1); box-shadow: 0 2px 4px rgba(52, 66, 81, .1), 0 0 0 1px rgba(52, 66, 81, .1); color: #576a7f; font-size: 12px; line-height: 36px; z-index: 1020; padding: 0; position: fixed; -webkit-transition: all .3s ease; -o-transition: all .3s ease; transition: all .3s ease;">
                        <form class="smenu__form" data-smenu-range="true" action="/cars-for-sale/toyota/86/malaysia" method="GET" data-smenu-vehicle-type="car" style="-webkit-box-sizing: border-box; box-sizing: border-box; margin: 0; padding: 0;">
                        </form>
                        <form class="smenu__form__keyword" action="car" method="GET" style="-webkit-box-sizing: border-box; box-sizing: border-box; margin: 0; padding: 0;">
                        </form>
                        <div class="smenu__header  weight--semibold  flexbox" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: table; width: 100%; background-color: #02aaee; border-radius: 4px 4px 0 0; color: #fff; padding: 0 12px; font-weight: 500;">
                            <div class="flexbox__item  action  action--left  tight  visuallyhidden--desk-wide  js-smenu-close" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: table-cell; vertical-align: middle; white-space: nowrap; width: 1px;">
                                <div class="smenu__back  icon  icon--md-arrow-back  visuallyhidden--lap-and-up" style="-webkit-box-sizing: border-box; box-sizing: border-box; zoom: 1; display: inline-block; font-size: 16px; font-style: normal; font-weight: 400; line-height: inherit; position: relative; text-align: center; vertical-align: middle;"></div>
                                <div class="smenu__back  icon  icon--md-close  visuallyhidden--palm" style="-webkit-box-sizing: border-box; box-sizing: border-box; zoom: 1; display: inline-block; font-size: 16px; font-style: normal; font-weight: 400; line-height: inherit; position: relative; text-align: center; vertical-align: middle;"></div>
                            </div>

                            <div class="flexbox__item" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: table-cell; vertical-align: middle;">
                                Search Filters        </div>

                            <div class="flexbox__item  action  action--right  tight  visuallyhidden--desk-wide  js-smenu-reset  js-smenu__do-ajaxify" data-url="https://www.carlist.my/cars-for-sale/malaysia" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: table-cell; vertical-align: middle; white-space: nowrap; width: 1px;">
                                Reset        </div>
                        </div><!-- .smenu__header -->
                        <div class="smenu__fields" style="-webkit-box-sizing: border-box; box-sizing: border-box;">
                            <div class="smenu__fields__container" style="-webkit-box-sizing: border-box; box-sizing: border-box;">
                                <div class="smenu__field smenu__field--overview  visuallyhidden--desk-end" style="-webkit-box-sizing: border-box; box-sizing: border-box; border-bottom: 1px solid #e6e9ef; line-height: 36px; position: relative;">
                                    <div class="smenu__btn" style="-webkit-box-sizing: border-box; box-sizing: border-box; outline: none; overflow: hidden; padding-left: 12px; padding-right: 4px; font-size: 0; text-align: center; cursor: default;">
                                        <a class="smenu__side" href="https://www.carlist.my/cars-for-sale/malaysia" style="-webkit-box-sizing: border-box; box-sizing: border-box; background-color: transparent; -webkit-transition: all 0.3s ease; transition: all 0.3s ease; color: #02aaee; cursor: pointer; text-decoration: none; overflow: hidden; display: block; float: none; text-align: center; font-family: bmwTypeNextWeb, Arial, Helvetica, sans-serif; font-style: normal; font-weight: 700;">
                                            <span class="inline--block  valign--top  smenu__value" style="-webkit-box-sizing: border-box; box-sizing: border-box; border-radius: 4px 0 0 4px; overflow: hidden; -o-text-overflow: ellipsis; text-overflow: ellipsis; white-space: nowrap; background-color: #02aaee; float: none; font-size: 12px; font-weight: 500; line-height: 24px; margin: 10px 3px; max-width: 1000px; padding: 0; vertical-align: top; display: inline-block; color: #02aaee; background: none;">Reset Search</span>
                                            <span class="inline--block  valign--top  smenu__addon-icon  icon  icon--md-reset" style="-webkit-box-sizing: border-box; box-sizing: border-box; zoom: 1; font-style: normal; position: relative; text-align: center; float: none; font-size: 12px; font-weight: 500; line-height: 24px; margin: 10px 3px; max-width: 1000px; padding: 0; vertical-align: top; display: inline-block; background: none;"></span>
                                        </a>
                                    </div>
                                </div>


                                <div class="smenu__section  smenu__section--finder  visuallyhidden--desk-wide" style="-webkit-box-sizing: border-box; box-sizing: border-box;">
                                    <div class="container" style="-webkit-box-sizing: border-box; box-sizing: border-box; width: 100%; margin-right: auto; margin-left: auto; margin: 0 auto; max-width: 1120px; padding-left: 20px; padding-right: 20px;">
                                        <div class="smenu__keyword  input-group  smenu__input  smenu__input--text  smenu__input--has-prepend  smenu__input--has-append" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: -ms-flexbox; display: flex; -ms-flex-wrap: wrap; flex-wrap: wrap; -ms-flex-align: stretch; align-items: stretch; width: 100%; position: relative;">
                                            <div class="smenu__input__prepend  icon  icon--magnifier  append--before" style="-webkit-box-sizing: border-box; box-sizing: border-box; zoom: 1; display: inline-block; font-style: normal; font-weight: 400; vertical-align: middle; color: #cfd6df; font-size: 14px; height: 20px; line-height: 20px; margin-top: -10px; position: absolute; text-align: center; top: 50%; width: 36px; z-index: 2; left: 0; right: auto;"></div>
                                            <div class="smenu__input__prepend  smenu__back  icon  icon--md-arrow-back  hidden  js-smenu__close-dropdown--filter" style="-webkit-box-sizing: border-box; box-sizing: border-box; zoom: 1; font-style: normal; font-weight: 400; vertical-align: middle; display: none; color: #cfd6df; font-size: 14px; height: 20px; left: 0; line-height: 20px; margin-top: -10px; position: absolute; text-align: center; top: 50%; width: 36px; z-index: 2;"></div>
                                            <div class="smenu__input__input" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: block; height: 32px;">
                                                <input type="search" name="name" value="" class="input  one-whole  smenu__form-input--keyword" autocomplete="off" data-smenu-filter=".smenu__select--keyword" placeholder="e.g. Honda Civic" style="-webkit-box-sizing: border-box; box-sizing: border-box; overflow: visible; -webkit-transition: all 0.3s ease; transition: all 0.3s ease; font-family: inherit; letter-spacing: inherit; margin: 0; outline-offset: -2px; -webkit-appearance: none; -moz-appearance: none; appearance: none; background: #fff; border: 1px solid #cfd6df; border-radius: 4px; cursor: text; display: inline-block; outline: none; padding: 7px 12px; padding-left: 36px; font-size: 12px; height: 32px; line-height: 16px; max-width: 100%; vertical-align: top; width: 100%; color: #576a7f;">
                                            </div>
                                            <div class="smenu__input__append smenu__form-input--keyword-clear icon icon--wrong-circle append--after visuallyhidden" style="-webkit-box-sizing: border-box; box-sizing: border-box; zoom: 1; display: inline-block; font-style: normal; font-weight: 400; vertical-align: middle; line-height: 20px; margin-top: -10px; text-align: center; top: 50%; z-index: 2; color: #73879b; font-size: 16px; left: auto; clip: rect(0 0 0 0); border: 0; height: 1px; margin: -1px; overflow: hidden; padding: 0; position: absolute; width: 1px; right: 4px;"></div>
                                        </div>
                                    </div>
                                </div>

                                <!-- @ UWP-2587 -->
                                {{--<div class="smenu__section" style="-webkit-box-sizing: border-box; box-sizing: border-box;">--}}
                                    {{--<div class="container  visuallyhidden--desk-wide  smenu__field-group--options" style="-webkit-box-sizing: border-box; box-sizing: border-box; width: 100%; margin-right: auto; margin-left: auto; margin: 0 auto; max-width: 1120px; padding-left: 20px; padding-right: 20px;">--}}
                                        {{--<div class="milli  text--muted  push-quarter--bottom inline--block" style="-webkit-box-sizing: border-box; box-sizing: border-box; font-size: 12px; line-height: 16px; color: #8a9bad; margin-bottom: 5px; display: inline-block;">More Options</div>--}}
                                        {{--<div class="badge--new  badge--new--desktop  text--uppercase  weight--semibold  nano  text--white  text--center  inline--block" style="-webkit-box-sizing: border-box; box-sizing: border-box; font-size: 9px; line-height: 12px; background-color: #fa0204; border-radius: 4px 4px 0 0; padding: 2px 4px; left: -26px; top: 10px; -webkit-transform: rotate(270deg); -ms-transform: rotate(270deg); transform: rotate(270deg); width: 36px; color: #fff; text-align: center; text-transform: uppercase; font-weight: 500; display: inline-block;">New</div>--}}
                                    {{--</div>--}}
                                    {{--<div class="smenu__field   smenu__field-show-car-with   js-menu-slug--show_cars_with" data-smenu-toggle=".smenu__filter--show-cars-with" data-smenu-slug="show_cars_with" style="-webkit-box-sizing: border-box; box-sizing: border-box; border-bottom: 1px solid #e6e9ef; line-height: 36px; position: relative;">--}}
                                        {{--<div class="badge--new  badge--new--desktop  text--uppercase  weight--semibold  nano  text--white  text--center  absolute  visuallyhidden--desk-end" style="-webkit-box-sizing: border-box; box-sizing: border-box; font-size: 9px; line-height: 12px; background-color: #fa0204; border-radius: 4px 4px 0 0; padding: 2px 4px; left: -26px; top: 10px; -webkit-transform: rotate(270deg); -ms-transform: rotate(270deg); transform: rotate(270deg); width: 36px; color: #fff; text-align: center; text-transform: uppercase; font-weight: 500; position: absolute;">New</div>--}}
                                        {{--<div class="smenu__btn  relative" style="-webkit-box-sizing: border-box; box-sizing: border-box; cursor: pointer; outline: none; overflow: hidden; padding-left: 12px; padding-right: 4px; position: relative;">--}}
                                            {{--<div class="smenu__label  float--left  weight--semibold" style="-webkit-box-sizing: border-box; box-sizing: border-box; float: left; font-weight: 500;">Show Cars With</div>--}}
                                            {{--<div class="smenu__side" style="-webkit-box-sizing: border-box; box-sizing: border-box; overflow: hidden;">--}}
                                           {{--<div style="float:right"><i class="la la-angle-right"></i></div>--}}
                                            {{--</div>--}}
                                        {{--</div>--}}
                                    {{--</div>--}}
                                {{--</div>--}}


                                {{--<div class="smenu__section" style="-webkit-box-sizing: border-box; box-sizing: border-box;">--}}
                                    {{--<div class="container  smenu__field-group--condition  visuallyhidden--desk-wide" style="-webkit-box-sizing: border-box; box-sizing: border-box; width: 100%; margin-right: auto; margin-left: auto; margin: 0 auto; max-width: 1120px; padding-left: 20px; padding-right: 20px;">--}}
                                        {{--<div class="milli  text--muted  push-quarter--bottom" style="-webkit-box-sizing: border-box; box-sizing: border-box; font-size: 12px; line-height: 16px; color: #8a9bad; margin-bottom: 5px;">Condition</div>--}}
                                    {{--</div>--}}
                                    {{--<div class="smenu__field  smenu__field--ad-type   js-menu-slug--type" data-smenu-toggle=".smenu__filter--ad-type" data-smenu-slug="type" style="-webkit-box-sizing: border-box; box-sizing: border-box; border-bottom: 1px solid #e6e9ef; line-height: 36px; position: relative;">--}}
                                        {{--<div class="smenu__btn  relative" style="-webkit-box-sizing: border-box; box-sizing: border-box; cursor: pointer; outline: none; overflow: hidden; padding-left: 12px; padding-right: 4px; position: relative;">--}}
                                            {{--<div class="smenu__label  float--left  weight--semibold" style="-webkit-box-sizing: border-box; box-sizing: border-box; float: left; font-weight: 500;">Condition</div>--}}
                                            {{--<div style="float:right"><i class="la la-angle-right"></i></div>--}}

                                        {{--</div>--}}
                                    {{--</div>--}}
                                {{--</div>--}}

                                {{--<div class="smenu__section  visuallyhidden--desk-wide" style="-webkit-box-sizing: border-box; box-sizing: border-box;">--}}
                                    {{--<div class="container  smenu__field-group--hotdeal" style="-webkit-box-sizing: border-box; box-sizing: border-box; width: 100%; margin-right: auto; margin-left: auto; margin: 0 auto; max-width: 1120px; padding-left: 20px; padding-right: 20px;">--}}
                                        {{--<div class="milli  text--muted  push-quarter--bottom" style="-webkit-box-sizing: border-box; box-sizing: border-box; font-size: 12px; line-height: 16px; color: #8a9bad; margin-bottom: 5px;">Special Offer</div>--}}
                                    {{--</div>--}}
                                    {{--<div class="smenu__field  smenu__field--hotdeal" style="-webkit-box-sizing: border-box; box-sizing: border-box; border-bottom: 1px solid #e6e9ef; line-height: 36px; position: relative;">--}}
                                        {{--<div class="smenu__btn  smenu__btn--toggle" style="-webkit-box-sizing: border-box; box-sizing: border-box; cursor: pointer; outline: none; overflow: hidden; padding-left: 12px; padding-right: 4px;">--}}
                                            {{--<div class="smenu__icon  smenu__icon--hotdeal" style="-webkit-box-sizing: border-box; box-sizing: border-box; color: #cfd6df; cursor: pointer; float: right;"></div>--}}
                                            {{--<label class="js-smenu__do-ajaxify" data-url="https://www.carlist.my/cars-for-sale/toyota/86/malaysia?hotdeal=true" for="facet-hot-deal" data-scroll-to=".smenu__field-group--hotdeal" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: inline-block; margin-bottom: .5rem; border-radius: 0; cursor: default;">--}}
                                                {{--<input name="facet-hot-deal" id="facet-hot-deal" type="checkbox" class="visuallyhidden" style="-webkit-transition: all 0.3s ease; transition: all 0.3s ease; font-family: inherit; font-size: 100%; letter-spacing: inherit; line-height: normal; border-radius: 0; cursor: default; -webkit-box-sizing: border-box; box-sizing: border-box; clip: rect(0 0 0 0); border: 0; height: 1px; margin: -1px; overflow: hidden; padding: 0; position: absolute; width: 1px;">--}}
                                                {{--<div class="smenu__toggle  float--right" style="-webkit-box-sizing: border-box; box-sizing: border-box; background-color: #cfd6df; border-radius: 10px; cursor: pointer; height: 20px; position: relative; width: 40px; float: right;"></div>--}}
                                                {{--<div style="-webkit-box-sizing: border-box; box-sizing: border-box;">Show Hot Deal</div>--}}
                                            {{--</label>--}}
                                        {{--</div>--}}
                                    {{--</div>--}}
                                {{--</div>--}}

                                <div class="smenu__section" style="-webkit-box-sizing: border-box; box-sizing: border-box;">
                                    {{--<div class="container  visuallyhidden--desk-wide  smenu__field-group--make" style="-webkit-box-sizing: border-box; box-sizing: border-box; width: 100%; margin-right: auto; margin-left: auto; margin: 0 auto; max-width: 1120px; padding-left: 20px; padding-right: 20px;">--}}
                                        {{--<div class="milli  text--muted  push-quarter--bottom" style="-webkit-box-sizing: border-box; box-sizing: border-box; font-size: 12px; line-height: 16px; color: #8a9bad; margin-bottom: 5px;">--}}
                                            {{--Brand,--}}
                                            {{--Model, and Variant        </div>--}}
                                    {{--</div>--}}

                                    {{--<div class="smenu__field    smenu__field--state-active js-menu-slug--make" data-smenu-toggle=".smenu__filter--brand" data-smenu-input-focus=".smenu__form-input--brand" data-smenu-slug="make" style="-webkit-box-sizing: border-box; box-sizing: border-box; border-bottom: 1px solid #e6e9ef; line-height: 36px; position: relative; background: #f7f8fa;">--}}
                                        {{--<div class="smenu__btn  relative" style="-webkit-box-sizing: border-box; box-sizing: border-box; cursor: pointer; outline: none; overflow: hidden; padding-left: 12px; padding-right: 4px; position: relative;">--}}
                                            {{--<div class="smenu__label  float--left  weight--semibold" style="-webkit-box-sizing: border-box; box-sizing: border-box; float: left; font-weight: 500;">Brand</div>--}}
                                            {{--<div class="smenu__side" style="-webkit-box-sizing: border-box; box-sizing: border-box; overflow: hidden;">--}}
                                                {{--<div style="float:right"><i class="la la-angle-right"></i></div>--}}
                                                {{--<div class="smenu__value" style="">Toyota</div>--}}
                                            {{--</div>--}}
                                        {{--</div>--}}
                                    {{--</div>--}}


                                    {{--<div class="smenu__field      smenu__field--state-active js-menu-slug--model" data-smenu-toggle=".smenu__filter--model" data-smenu-input-focus=".smenu__form-input--model" data-smenu-slug="model" style="-webkit-box-sizing: border-box; box-sizing: border-box; border-bottom: 1px solid #e6e9ef; line-height: 36px; position: relative; background: #f7f8fa;">--}}
                                        {{--<div class="smenu__btn  relative" style="-webkit-box-sizing: border-box; box-sizing: border-box; cursor: pointer; outline: none; overflow: hidden; padding-left: 12px; padding-right: 4px; position: relative;">--}}
                                            {{--<div class="smenu__label  float--left  weight--semibold" style="-webkit-box-sizing: border-box; box-sizing: border-box; float: left; font-weight: 500;">Model</div>--}}
                                            {{--<div class="smenu__side" style="-webkit-box-sizing: border-box; box-sizing: border-box; overflow: hidden;">--}}
                                                {{--<div style="float:right"><i class="la la-angle-right"></i></div>--}}
                                                {{--<div class="smenu__value" style="">--}}
                                                    {{--86                    </div>--}}
                                            {{--</div>--}}
                                        {{--</div>--}}
                                    {{--</div>--}}


                                    <div class="vart smenu__field js-menu-slug--variant smenu__field--show-content" data-smenu-toggle=".smenu__filter--variant" data-smenu-slug="variant" style="-webkit-box-sizing: border-box; box-sizing: border-box; border-bottom: 1px solid #e6e9ef; line-height: 36px; position: relative;">
                                        <div class="smenu__btn  relative" style="-webkit-box-sizing: border-box; box-sizing: border-box; cursor: pointer; outline: none; overflow: hidden; padding-left: 12px; padding-right: 4px; position: relative;">
                                            <div class="smenu__label  float--left  weight--semibold" style="-webkit-box-sizing: border-box; box-sizing: border-box; float: left; font-weight: 500; color: #02aaee;">Brand</div>
                                            <div class="smenu__side" style="-webkit-box-sizing: border-box; box-sizing: border-box; overflow: hidden;">
                                                <div class="" style="float:right"><i class="la la-angle-right"></i></div>
                                                <div class="smenu__value" style="">
                                                    <form action="" method="get">
                                                        <input type="hidden" name="y_id" value="{{ isset($y_id)? $y_id : ''}}">
                                                        <input type="hidden" name="cd_id" value="{{ isset($cd_id)? $cd_id : ''}}">
                                                        <input type="hidden" name="ct_id" value="{{ isset($ct_id)? $ct_id : ''}}">
                                                        <input type="hidden" name="m_id" value="{{ isset($m_r_id)? $m_r_id : ''}}">
                                                        <input type="hidden" name="category_id" value="{{ $cat->name }}">
                                                    {{ isset($b_id)? \App\Brand::where('id', $b_id)->first()->name: ''}}
                                                        @if(isset($b_id))
                                                        <button type="submit" class="btn btn-sm btn-default"> <span><i class="la la-close"></i></span></button>
                                                            @endif
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="vartModels smenu__field js-menu-slug--variant smenu__field--show-content" data-smenu-toggle=".smenu__filter--variant" data-smenu-slug="variant" style="-webkit-box-sizing: border-box; box-sizing: border-box; border-bottom: 1px solid #e6e9ef; line-height: 36px; position: relative;">
                                        <div class="smenu__btn  relative" style="-webkit-box-sizing: border-box; box-sizing: border-box; cursor: pointer; outline: none; overflow: hidden; padding-left: 12px; padding-right: 4px; position: relative;">
                                            <div class="smenu__label  float--left  weight--semibold" style="-webkit-box-sizing: border-box; box-sizing: border-box; float: left; font-weight: 500; color: #02aaee;">Models</div>
                                            <div class="smenu__side" style="-webkit-box-sizing: border-box; box-sizing: border-box; overflow: hidden;">
                                                <div class="" style="float:right"><i class="la la-angle-right"></i></div>
                                                <div class="smenu__value" style="">
                                                    <form action="" method="get">
                                                        <input type="hidden" name="y_id" value="{{ isset($y_id)? $y_id : ''}}">
                                                        <input type="hidden" name="cd_id" value="{{ isset($cd_id)? $cd_id : ''}}">
                                                        <input type="hidden" name="ct_id" value="{{ isset($ct_id)? $ct_id : ''}}">
                                                        <input type="hidden" name="m_id" value="{{ isset($m_r_id)? $m_r_id : ''}}">
                                                        <input type="hidden" name="category_id" value="{{ $cat->name }}">
                                                        {{ isset($m_r_id)? \App\CarModel::where('id', $m_r_id)->first()->name: ''}}
                                                        @if(isset($m_r_id))
                                                            <button type="submit" class="btn btn-sm btn-default"> <span><i class="la la-close"></i></span></button>
                                                        @endif
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="vartDetails smenu__field js-menu-slug--variant smenu__field--show-content" data-smenu-toggle=".smenu__filter--variant" data-smenu-slug="variant" style="-webkit-box-sizing: border-box; box-sizing: border-box; border-bottom: 1px solid #e6e9ef; line-height: 36px; position: relative;">
                                        <div class="smenu__btn  relative" style="-webkit-box-sizing: border-box; box-sizing: border-box; cursor: pointer; outline: none; overflow: hidden; padding-left: 12px; padding-right: 4px; position: relative;">
                                            <div class="smenu__label  float--left  weight--semibold" style="-webkit-box-sizing: border-box; box-sizing: border-box; float: left; font-weight: 500; color: #02aaee;">Car Details</div>
                                            <div class="smenu__side" style="-webkit-box-sizing: border-box; box-sizing: border-box; overflow: hidden;">
                                                <div class="" style="float:right"><i class="la la-angle-right"></i></div>
                                                <div class="smenu__value" style="">
                                                    {{ isset($cd_id)? \App\CarDetail::where('id', $cd_id)->first()->name: ''}}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="vartYears smenu__field js-menu-slug--variant smenu__field--show-content" data-smenu-toggle=".smenu__filter--variant" data-smenu-slug="variant" style="-webkit-box-sizing: border-box; box-sizing: border-box; border-bottom: 1px solid #e6e9ef; line-height: 36px; position: relative;">
                                        <div class="smenu__btn  relative" style="-webkit-box-sizing: border-box; box-sizing: border-box; cursor: pointer; outline: none; overflow: hidden; padding-left: 12px; padding-right: 4px; position: relative;">
                                            <div class="smenu__label  float--left  weight--semibold" style="-webkit-box-sizing: border-box; box-sizing: border-box; float: left; font-weight: 500; color: #02aaee;">Car Years</div>
                                            <div class="smenu__side" style="-webkit-box-sizing: border-box; box-sizing: border-box; overflow: hidden;">
                                                <div class="" style="float:right"><i class="la la-angle-right"></i></div>
                                                <div class="smenu__value" style="">
                                                    {{ isset($y_id)? \App\CarYear::where('id', $y_id)->first()->name: ''}}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="vartTypes smenu__field js-menu-slug--variant smenu__field--show-content" data-smenu-toggle=".smenu__filter--variant" data-smenu-slug="variant" style="-webkit-box-sizing: border-box; box-sizing: border-box; border-bottom: 1px solid #e6e9ef; line-height: 36px; position: relative;">
                                        <div class="smenu__btn  relative" style="-webkit-box-sizing: border-box; box-sizing: border-box; cursor: pointer; outline: none; overflow: hidden; padding-left: 12px; padding-right: 4px; position: relative;">
                                            <div class="smenu__label  float--left  weight--semibold" style="-webkit-box-sizing: border-box; box-sizing: border-box; float: left; font-weight: 500; color: #02aaee;">Car Types</div>
                                            <div class="smenu__side" style="-webkit-box-sizing: border-box; box-sizing: border-box; overflow: hidden;">
                                                <div class="" style="float:right"><i class="la la-angle-right"></i></div>
                                                <div class="smenu__value" style="">
                                                    {{ isset($ct_id)? \App\CarType::where('id', $ct_id)->first()->name: ''}}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div><!-- end:.smenu__section -->

                            </div>
                        </div><!-- .smenu__fields -->

                        <div class="smenu__filters" style="-webkit-box-sizing: border-box; box-sizing: border-box;">


                            {{--smenu__filter--show-myself--}}
                            <div class="smenu_varients smenu__filter smenu__filter--variant smenu__filter--show-myselff">
                                <div class="smenu__filter-header" style="-webkit-box-sizing: border-box; box-sizing: border-box; padding-left: 12px; padding-right: 12px;">
                                    <div class="flexbox  weight--semibold" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: table; width: 100%; font-weight: 500;">
                                        <div class="flexbox__item" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: table-cell; vertical-align: middle;">Select Car Brand</div>
                                        <div class="flexbox__item  tight" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: table-cell; vertical-align: middle; white-space: nowrap; width: 1px;"><span class="smenu__icon  smenu__icon--remove  js-smenu__close-dropdown--filter" data-smenu-close="true" style="-webkit-box-sizing: border-box; box-sizing: border-box; line-height: 28px; margin: 4px 0; border-radius: 0 4px 4px 0; padding: 0 5px; cursor: pointer; float: right; background-color: #02aaee; background: none; color: #02aaee;"><span class="visuallyhidden--desk" style="-webkit-box-sizing: border-box; box-sizing: border-box;">Cancel</span></span>
                                        </div>
                                    </div>
                                </div>

                                <div class="smenu__filter-finder  soft-half--sides  soft-quarter--ends  visuallyhidden--portable" style="-webkit-box-sizing: border-box; box-sizing: border-box; padding-left: 10px; padding-right: 10px; padding-bottom: 5px; padding-top: 5px;">

                                    <div class="input-group smenu__input smenu__input--text smenu__input--has-prepend smenu__input--has-append" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: -ms-flexbox; display: flex; -ms-flex-wrap: wrap; flex-wrap: wrap; -ms-flex-align: stretch; align-items: stretch; width: 100%; position: relative;">
                                        <div class="smenu__input__prepend icon  icon--magnifier  append--before" style="-webkit-box-sizing: border-box; box-sizing: border-box; zoom: 1; display: inline-block; font-style: normal; font-weight: 400; vertical-align: middle; color: #cfd6df; font-size: 14px; height: 20px; line-height: 20px; margin-top: -10px; position: absolute; text-align: center; top: 50%; width: 36px; z-index: 2; left: 0; right: auto;"></div>
                                        <span class="smenu__input__input" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: block; height: 32px;">
        <input id="searchBrandFilter" class="input smenu__form-input--variant smenu__form-input--dropdown-filter js-smenu__form-input--dropdown-filter" type="text" name="" value="" data-smenu-filter=".smenu__select--variant" placeholder="Search car variant" autocomplete="off" style="-webkit-box-sizing: border-box; box-sizing: border-box; overflow: visible; -webkit-transition: all 0.3s ease; transition: all 0.3s ease; font-family: inherit; letter-spacing: inherit; margin: 0; -webkit-appearance: none; -moz-appearance: none; appearance: none; background: #fff; border: 1px solid #cfd6df; border-radius: 4px; cursor: text; display: inline-block; outline: none; padding: 7px 12px; padding-left: 36px; font-size: 12px; height: 32px; line-height: 16px; max-width: 100%; vertical-align: top; width: 100%; color: #576a7f;">
    </span>
                                        <span data-target-input=".smenu__form-input--variant" class=" js-smenu__do-input-clear smenu__input__append icon icon--wrong-circle append--after  visuallyhidden" style="-webkit-box-sizing: border-box; box-sizing: border-box; zoom: 1; display: inline-block; font-style: normal; font-weight: 400; vertical-align: middle; line-height: 20px; margin-top: -10px; text-align: center; top: 50%; z-index: 2; color: #73879b; font-size: 16px; left: auto; clip: rect(0 0 0 0); border: 0; height: 1px; margin: -1px; overflow: hidden; padding: 0; position: absolute; width: 1px; right: 4px;"></span>
                                    </div>        </div>

                                <div class="brands_filter smenu__filter-content" style="-webkit-box-sizing: border-box; box-sizing: border-box; -webkit-overflow-scrolling: touch; overflow-y: auto; height: calc(100% - 78px);">
                                    <ul class="smenu__select smenu__select--variant" style="-webkit-box-sizing: border-box; box-sizing: border-box; margin-top: 0; margin-bottom: 1.3846153846rem; margin-left: 3.0769230769rem; list-style: none; margin: 0; padding: 0;">
                                        @foreach(\App\Brand::all() as $item)
                                            <form action="" method="get">
                                                <input type="hidden" name="y_id" value="{{ isset($y_id)? $y_id : ''}}">
                                                <input type="hidden" name="cd_id" value="{{ isset($cd_id)? $cd_id : ''}}">
                                                <input type="hidden" name="ct_id" value="{{ isset($ct_id)? $ct_id : ''}}">
                                                <input type="hidden" name="m_id" value="{{ isset($m_r_id)? $m_r_id : ''}}">
                                                <input type="hidden" name="b_id" value="{{ $item->id }}">
                                                <input type="hidden" name="category_id" value="{{ $cat->name }}">
                                            <li class="smenu__select__option  " data-value="BMW" data-scroll-to=".smenu__field-group--make">
                                                <button type="submit" class="btn btn-default">
                                                    <span class="smenu__select__option__icon  brand-small  brand-small--car  brand-small--bmw"></span>
                                                    <span class="smenu__select__option__value  brand-label  brand-label--small  text--truncate">
                                    <span class="text--muted  float--right"> </span>
                                                        {{ $item->getTranslation('name') }}
                                </span>
                                                </button>
                                            </li>
                                            </form>
                                     @endforeach
                                    </ul>
                                </div>
                            </div>


                            {{--Model Menus--}}
                            <div class="model_menus_varients smenu__filter smenu__filter--variant">
                                <div class="smenu__filter-header" style="-webkit-box-sizing: border-box; box-sizing: border-box; padding-left: 12px; padding-right: 12px;">
                                    <div class="flexbox  weight--semibold" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: table; width: 100%; font-weight: 500;">
                                        <div class="flexbox__item" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: table-cell; vertical-align: middle;">Select Car Brand</div>
                                        <div class="flexbox__item  tight" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: table-cell; vertical-align: middle; white-space: nowrap; width: 1px;"><span class="smenu__icon  smenu__icon--remove  js-smenu__close-dropdown--filter" data-smenu-close="true" style="-webkit-box-sizing: border-box; box-sizing: border-box; line-height: 28px; margin: 4px 0; border-radius: 0 4px 4px 0; padding: 0 5px; cursor: pointer; float: right; background-color: #02aaee; background: none; color: #02aaee;"><span class="visuallyhidden--desk" style="-webkit-box-sizing: border-box; box-sizing: border-box;">Cancel</span></span>
                                        </div>
                                    </div>
                                </div>

                                <div class="smenu__filter-finder  soft-half--sides  soft-quarter--ends  visuallyhidden--portable" style="-webkit-box-sizing: border-box; box-sizing: border-box; padding-left: 10px; padding-right: 10px; padding-bottom: 5px; padding-top: 5px;">

                                    <div class="input-group smenu__input smenu__input--text smenu__input--has-prepend smenu__input--has-append" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: -ms-flexbox; display: flex; -ms-flex-wrap: wrap; flex-wrap: wrap; -ms-flex-align: stretch; align-items: stretch; width: 100%; position: relative;">
                                        <div class="smenu__input__prepend icon  icon--magnifier  append--before" style="-webkit-box-sizing: border-box; box-sizing: border-box; zoom: 1; display: inline-block; font-style: normal; font-weight: 400; vertical-align: middle; color: #cfd6df; font-size: 14px; height: 20px; line-height: 20px; margin-top: -10px; position: absolute; text-align: center; top: 50%; width: 36px; z-index: 2; left: 0; right: auto;"></div>

                                        <span class="smenu__input__input" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: block; height: 32px;">
        <input id="searchModelFilter" class="input smenu__form-input--variant smenu__form-input--dropdown-filter js-smenu__form-input--dropdown-filter" type="text" name="" value="" data-smenu-filter=".smenu__select--variant" placeholder="Search car variant" autocomplete="off" style="-webkit-box-sizing: border-box; box-sizing: border-box; overflow: visible; -webkit-transition: all 0.3s ease; transition: all 0.3s ease; font-family: inherit; letter-spacing: inherit; margin: 0; -webkit-appearance: none; -moz-appearance: none; appearance: none; background: #fff; border: 1px solid #cfd6df; border-radius: 4px; cursor: text; display: inline-block; outline: none; padding: 7px 12px; padding-left: 36px; font-size: 12px; height: 32px; line-height: 16px; max-width: 100%; vertical-align: top; width: 100%; color: #576a7f;">

                                        </span>
                                        <span data-target-input=".smenu__form-input--variant" class=" js-smenu__do-input-clear smenu__input__append icon icon--wrong-circle append--after  visuallyhidden" style="-webkit-box-sizing: border-box; box-sizing: border-box; zoom: 1; display: inline-block; font-style: normal; font-weight: 400; vertical-align: middle; line-height: 20px; margin-top: -10px; text-align: center; top: 50%; z-index: 2; color: #73879b; font-size: 16px; left: auto; clip: rect(0 0 0 0); border: 0; height: 1px; margin: -1px; overflow: hidden; padding: 0; position: absolute; width: 1px; right: 4px;"></span>
                                    </div>        </div>

                                <div class="smenu__filter-content" style="-webkit-box-sizing: border-box; box-sizing: border-box; -webkit-overflow-scrolling: touch; overflow-y: auto; height: calc(100% - 78px);">
                                    <ul class="models_filter smenu__select smenu__select--variant" style="-webkit-box-sizing: border-box; box-sizing: border-box; margin-top: 0; margin-bottom: 1.3846153846rem; margin-left: 3.0769230769rem; list-style: none; margin: 0; padding: 0;">
                                        @foreach(\App\CarModel::all() as $item)
                                            <form action="" method="get">
                                                <input type="hidden" name="y_id" value="{{ isset($y_id)? $y_id : ''}}">
                                                <input type="hidden" name="b_id" value="{{ isset($b_id)? $b_id : ''}}">
                                                <input type="hidden" name="cd_id" value="{{ isset($cd_id)? $cd_id : ''}}">
                                                <input type="hidden" name="ct_id" value="{{ isset($ct_id)? $ct_id : ''}}">
                                            <input type="hidden" name="m_id" value="{{ $item->id }}">
                                            <input type="hidden" name="category_id" value="{{ $cat->name }}">
                                            <li class="smenu__select__option  " data-value="BMW" data-scroll-to=".smenu__field-group--make">
                                                <button type="submit" class="btn btn-default">
                                                    <span class="smenu__select__option__icon  brand-small  brand-small--car  brand-small--bmw"></span>
                                                    <span class="smenu__select__option__value  brand-label  brand-label--small  text--truncate">
                                    <span class="text--muted  float--right"> </span>
                                                     {{ $item->getTranslation('name') }}
                                </span>
                                                </button>
                                            </li>
                                            </form>
                                     @endforeach
                                    </ul>
                                </div>
                            </div>

                            {{--Details Menus--}}
                            <div class="detail_menus_varients smenu__filter smenu__filter--variant">
                                <div class="smenu__filter-header" style="-webkit-box-sizing: border-box; box-sizing: border-box; padding-left: 12px; padding-right: 12px;">
                                    <div class="flexbox  weight--semibold" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: table; width: 100%; font-weight: 500;">
                                        <div class="flexbox__item" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: table-cell; vertical-align: middle;">Select Car Brand</div>
                                        <div class="flexbox__item  tight" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: table-cell; vertical-align: middle; white-space: nowrap; width: 1px;"><span class="smenu__icon  smenu__icon--remove  js-smenu__close-dropdown--filter" data-smenu-close="true" style="-webkit-box-sizing: border-box; box-sizing: border-box; line-height: 28px; margin: 4px 0; border-radius: 0 4px 4px 0; padding: 0 5px; cursor: pointer; float: right; background-color: #02aaee; background: none; color: #02aaee;"><span class="visuallyhidden--desk" style="-webkit-box-sizing: border-box; box-sizing: border-box;">Cancel</span></span>
                                        </div>
                                    </div>
                                </div>

                                <div class="smenu__filter-finder  soft-half--sides  soft-quarter--ends  visuallyhidden--portable" style="-webkit-box-sizing: border-box; box-sizing: border-box; padding-left: 10px; padding-right: 10px; padding-bottom: 5px; padding-top: 5px;">

                                    <div class="input-group smenu__input smenu__input--text smenu__input--has-prepend smenu__input--has-append" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: -ms-flexbox; display: flex; -ms-flex-wrap: wrap; flex-wrap: wrap; -ms-flex-align: stretch; align-items: stretch; width: 100%; position: relative;">
                                        <div class="smenu__input__prepend icon  icon--magnifier  append--before" style="-webkit-box-sizing: border-box; box-sizing: border-box; zoom: 1; display: inline-block; font-style: normal; font-weight: 400; vertical-align: middle; color: #cfd6df; font-size: 14px; height: 20px; line-height: 20px; margin-top: -10px; position: absolute; text-align: center; top: 50%; width: 36px; z-index: 2; left: 0; right: auto;"></div>
                                        <span class="smenu__input__input" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: block; height: 32px;">
        <input id="searchDetailsFilter" class="input smenu__form-input--variant smenu__form-input--dropdown-filter js-smenu__form-input--dropdown-filter" type="text" name="" value="" data-smenu-filter=".smenu__select--variant" placeholder="Search car variant" autocomplete="off" style="-webkit-box-sizing: border-box; box-sizing: border-box; overflow: visible; -webkit-transition: all 0.3s ease; transition: all 0.3s ease; font-family: inherit; letter-spacing: inherit; margin: 0; -webkit-appearance: none; -moz-appearance: none; appearance: none; background: #fff; border: 1px solid #cfd6df; border-radius: 4px; cursor: text; display: inline-block; outline: none; padding: 7px 12px; padding-left: 36px; font-size: 12px; height: 32px; line-height: 16px; max-width: 100%; vertical-align: top; width: 100%; color: #576a7f;">
    </span>
                                        <span data-target-input=".smenu__form-input--variant" class=" js-smenu__do-input-clear smenu__input__append icon icon--wrong-circle append--after  visuallyhidden" style="-webkit-box-sizing: border-box; box-sizing: border-box; zoom: 1; display: inline-block; font-style: normal; font-weight: 400; vertical-align: middle; line-height: 20px; margin-top: -10px; text-align: center; top: 50%; z-index: 2; color: #73879b; font-size: 16px; left: auto; clip: rect(0 0 0 0); border: 0; height: 1px; margin: -1px; overflow: hidden; padding: 0; position: absolute; width: 1px; right: 4px;"></span>
                                    </div>        </div>

                                <div class="details_filter smenu__filter-content" style="-webkit-box-sizing: border-box; box-sizing: border-box; -webkit-overflow-scrolling: touch; overflow-y: auto; height: calc(100% - 78px);">
                                    <ul class="smenu__select smenu__select--variant" style="-webkit-box-sizing: border-box; box-sizing: border-box; margin-top: 0; margin-bottom: 1.3846153846rem; margin-left: 3.0769230769rem; list-style: none; margin: 0; padding: 0;">
                                        @foreach(\App\CarDetail::all() as $item)
                                            <form action="" method="get">
                                                <input type="hidden" name="y_id" value="{{ isset($y_id)? $y_id : ''}}">
                                                <input type="hidden" name="b_id" value="{{ isset($b_id)? $b_id : ''}}">
                                                <input type="hidden" name="m_id" value="{{ isset($m_r_id)? $m_r_id : ''}}">
                                                <input type="hidden" name="cd_id" value="{{ $item->id }}">
                                                <input type="hidden" name="ct_id" value="{{ isset($ct_id)? $ct_id : ''}}">
                                                <input type="hidden" name="category_id" value="{{ $cat->name }}">
                                            <li class="smenu__select__option  " data-value="BMW" data-scroll-to=".smenu__field-group--make">
                                                <button type="submit" class="btn btn-default">
                                                    <span class="smenu__select__option__icon  brand-small  brand-small--car  brand-small--bmw"></span>
                                                    <span class="smenu__select__option__value  brand-label  brand-label--small  text--truncate">
                                    <span class="text--muted  float--right"> </span>
                                                        {{ $item->getTranslation('name') }}
                                </span>
                                                </button>
                                            </li>
                                            </form>
                                     @endforeach
                                    </ul>
                                </div>
                            </div>
                            
                            {{--Years Menus--}}
                            <div class="year_menus_varients smenu__filter smenu__filter--variant">
                                <div class="smenu__filter-header" style="-webkit-box-sizing: border-box; box-sizing: border-box; padding-left: 12px; padding-right: 12px;">
                                    <div class="flexbox  weight--semibold" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: table; width: 100%; font-weight: 500;">
                                        <div class="flexbox__item" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: table-cell; vertical-align: middle;">Select Car Brand</div>
                                        <div class="flexbox__item  tight" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: table-cell; vertical-align: middle; white-space: nowrap; width: 1px;"><span class="smenu__icon  smenu__icon--remove  js-smenu__close-dropdown--filter" data-smenu-close="true" style="-webkit-box-sizing: border-box; box-sizing: border-box; line-height: 28px; margin: 4px 0; border-radius: 0 4px 4px 0; padding: 0 5px; cursor: pointer; float: right; background-color: #02aaee; background: none; color: #02aaee;"><span class="visuallyhidden--desk" style="-webkit-box-sizing: border-box; box-sizing: border-box;">Cancel</span></span>
                                        </div>
                                    </div>
                                </div>

                                <div class="smenu__filter-finder  soft-half--sides  soft-quarter--ends  visuallyhidden--portable" style="-webkit-box-sizing: border-box; box-sizing: border-box; padding-left: 10px; padding-right: 10px; padding-bottom: 5px; padding-top: 5px;">

                                    <div class="input-group smenu__input smenu__input--text smenu__input--has-prepend smenu__input--has-append" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: -ms-flexbox; display: flex; -ms-flex-wrap: wrap; flex-wrap: wrap; -ms-flex-align: stretch; align-items: stretch; width: 100%; position: relative;">
                                        <div class="smenu__input__prepend icon  icon--magnifier  append--before" style="-webkit-box-sizing: border-box; box-sizing: border-box; zoom: 1; display: inline-block; font-style: normal; font-weight: 400; vertical-align: middle; color: #cfd6df; font-size: 14px; height: 20px; line-height: 20px; margin-top: -10px; position: absolute; text-align: center; top: 50%; width: 36px; z-index: 2; left: 0; right: auto;"></div>
                                        <span class="smenu__input__input" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: block; height: 32px;">

        <input id="searchYearsFilter" class="input smenu__form-input--variant smenu__form-input--dropdown-filter js-smenu__form-input--dropdown-filter" type="text" name="" value="" data-smenu-filter=".smenu__select--variant" placeholder="Search car variant" autocomplete="off" style="-webkit-box-sizing: border-box; box-sizing: border-box; overflow: visible; -webkit-transition: all 0.3s ease; transition: all 0.3s ease; font-family: inherit; letter-spacing: inherit; margin: 0; -webkit-appearance: none; -moz-appearance: none; appearance: none; background: #fff; border: 1px solid #cfd6df; border-radius: 4px; cursor: text; display: inline-block; outline: none; padding: 7px 12px; padding-left: 36px; font-size: 12px; height: 32px; line-height: 16px; max-width: 100%; vertical-align: top; width: 100%; color: #576a7f;">

    </span>
                                        <span data-target-input=".smenu__form-input--variant" class=" js-smenu__do-input-clear smenu__input__append icon icon--wrong-circle append--after  visuallyhidden" style="-webkit-box-sizing: border-box; box-sizing: border-box; zoom: 1; display: inline-block; font-style: normal; font-weight: 400; vertical-align: middle; line-height: 20px; margin-top: -10px; text-align: center; top: 50%; z-index: 2; color: #73879b; font-size: 16px; left: auto; clip: rect(0 0 0 0); border: 0; height: 1px; margin: -1px; overflow: hidden; padding: 0; position: absolute; width: 1px; right: 4px;"></span>
                                    </div>        </div>

                                <div class="years_filter smenu__filter-content" style="-webkit-box-sizing: border-box; box-sizing: border-box; -webkit-overflow-scrolling: touch; overflow-y: auto; height: calc(100% - 78px);">
                                    <ul class="smenu__select smenu__select--variant" style="-webkit-box-sizing: border-box; box-sizing: border-box; margin-top: 0; margin-bottom: 1.3846153846rem; margin-left: 3.0769230769rem; list-style: none; margin: 0; padding: 0;">
                                        @foreach(\App\CarYear::all() as $item)
                                            <form action="" method="get">
                                                <input type="hidden" name="b_id" value="{{ isset($b_id)? $b_id : ''}}">
                                                <input type="hidden" name="m_id" value="{{ isset($m_r_id)? $m_r_id : ''}}">
                                                <input type="hidden" name="cd_id" value="{{ isset($cd_id)? $cd_id : ''}}">
                                                <input type="hidden" name="ct_id" value="{{ isset($ct_id)? $ct_id : ''}}">
                                                <input type="hidden" name="y_id" value="{{ $item->id }}">
                                                <input type="hidden" name="category_id" value="{{ $cat->name }}">
                                            <li class="smenu__select__option  " data-value="BMW" data-scroll-to=".smenu__field-group--make">
                                                <button type="submit" class="btn btn-default">
                                                    <span class="smenu__select__option__icon  brand-small  brand-small--car  brand-small--bmw"></span>
                                                    <span class="smenu__select__option__value  brand-label  brand-label--small  text--truncate">
                                    <span class="text--muted  float--right"> </span>
                                                      {{ $item->getTranslation('name') }}
                                </span>
                                                </button>
                                            </li>
                                            </form>
                                     @endforeach
                                    </ul>
                                </div>
                            </div>
                            
                            
                            {{--Types Menus--}}
                            <div class="type_menus_varients smenu__filter smenu__filter--variant">
                                <div class="smenu__filter-header" style="-webkit-box-sizing: border-box; box-sizing: border-box; padding-left: 12px; padding-right: 12px;">
                                    <div class="flexbox  weight--semibold" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: table; width: 100%; font-weight: 500;">
                                        <div class="flexbox__item" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: table-cell; vertical-align: middle;">Select Car Brand</div>
                                        <div class="flexbox__item  tight" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: table-cell; vertical-align: middle; white-space: nowrap; width: 1px;"><span class="smenu__icon  smenu__icon--remove  js-smenu__close-dropdown--filter" data-smenu-close="true" style="-webkit-box-sizing: border-box; box-sizing: border-box; line-height: 28px; margin: 4px 0; border-radius: 0 4px 4px 0; padding: 0 5px; cursor: pointer; float: right; background-color: #02aaee; background: none; color: #02aaee;"><span class="visuallyhidden--desk" style="-webkit-box-sizing: border-box; box-sizing: border-box;">Cancel</span></span>
                                        </div>
                                    </div>
                                </div>

                                <div class="smenu__filter-finder  soft-half--sides  soft-quarter--ends  visuallyhidden--portable" style="-webkit-box-sizing: border-box; box-sizing: border-box; padding-left: 10px; padding-right: 10px; padding-bottom: 5px; padding-top: 5px;">

                                    <div class="input-group smenu__input smenu__input--text smenu__input--has-prepend smenu__input--has-append" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: -ms-flexbox; display: flex; -ms-flex-wrap: wrap; flex-wrap: wrap; -ms-flex-align: stretch; align-items: stretch; width: 100%; position: relative;">
                                        <div class="smenu__input__prepend icon  icon--magnifier  append--before" style="-webkit-box-sizing: border-box; box-sizing: border-box; zoom: 1; display: inline-block; font-style: normal; font-weight: 400; vertical-align: middle; color: #cfd6df; font-size: 14px; height: 20px; line-height: 20px; margin-top: -10px; position: absolute; text-align: center; top: 50%; width: 36px; z-index: 2; left: 0; right: auto;"></div>
                                        <span class="smenu__input__input" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: block; height: 32px;">
        <input id="searchTypesFilter" class="input smenu__form-input--variant smenu__form-input--dropdown-filter js-smenu__form-input--dropdown-filter" type="text" name="" value="" data-smenu-filter=".smenu__select--variant" placeholder="Search car variant" autocomplete="off" style="-webkit-box-sizing: border-box; box-sizing: border-box; overflow: visible; -webkit-transition: all 0.3s ease; transition: all 0.3s ease; font-family: inherit; letter-spacing: inherit; margin: 0; -webkit-appearance: none; -moz-appearance: none; appearance: none; background: #fff; border: 1px solid #cfd6df; border-radius: 4px; cursor: text; display: inline-block; outline: none; padding: 7px 12px; padding-left: 36px; font-size: 12px; height: 32px; line-height: 16px; max-width: 100%; vertical-align: top; width: 100%; color: #576a7f;">
    </span>
                                        <span data-target-input=".smenu__form-input--variant" class=" js-smenu__do-input-clear smenu__input__append icon icon--wrong-circle append--after  visuallyhidden" style="-webkit-box-sizing: border-box; box-sizing: border-box; zoom: 1; display: inline-block; font-style: normal; font-weight: 400; vertical-align: middle; line-height: 20px; margin-top: -10px; text-align: center; top: 50%; z-index: 2; color: #73879b; font-size: 16px; left: auto; clip: rect(0 0 0 0); border: 0; height: 1px; margin: -1px; overflow: hidden; padding: 0; position: absolute; width: 1px; right: 4px;"></span>
                                    </div>        </div>

                                <div class="types_filter smenu__filter-content" style="-webkit-box-sizing: border-box; box-sizing: border-box; -webkit-overflow-scrolling: touch; overflow-y: auto; height: calc(100% - 78px);">
                                    <ul class="smenu__select smenu__select--variant" style="-webkit-box-sizing: border-box; box-sizing: border-box; margin-top: 0; margin-bottom: 1.3846153846rem; margin-left: 3.0769230769rem; list-style: none; margin: 0; padding: 0;">
                                        @foreach(\App\CarType::all() as $item)
                                            <form action="" method="get">
                                                <input type="hidden" name="y_id" value="{{ isset($y_id)? $y_id : ''}}">
                                                <input type="hidden" name="b_id" value="{{ isset($b_id)? $b_id : ''}}">
                                                <input type="hidden" name="m_id" value="{{ isset($m_r_id)? $m_r_id : ''}}">
                                                <input type="hidden" name="cd_id" value="{{ isset($cd_id)? $cd_id : ''}}">
                                                <input type="hidden" name="ct_id" value="{{ $item->id }}">
                                                <input type="hidden" name="category_id" value="{{ $cat->name }}">
                                            <li class="smenu__select__option  " data-value="BMW" data-scroll-to=".smenu__field-group--make">
                                                <button type="submit" class="btn btn-default">
                                                    <span class="smenu__select__option__icon  brand-small  brand-small--car  brand-small--bmw"></span>
                                                    <span class="smenu__select__option__value  brand-label  brand-label--small  text--truncate">
                                    <span class="text--muted  float--right"> </span>
                                                        {{ $item->getTranslation('name') }}
                                </span>
                                                </button>
                                            </li>
                                            </form>
                                     @endforeach
                                    </ul>
                                </div>
                            </div>
                            
                            
                            
                        </div>
                        <div class="smenu-action  text--center  one-whole  fixed  bottom--left  visuallyhidden--lap-and-up  transition--default" style="-webkit-box-sizing: border-box; box-sizing: border-box; width: 100%; bottom: 0; left: 0; text-align: center; position: fixed; -webkit-transition: all .3s ease; -o-transition: all .3s ease; transition: all .3s ease;">
                            <div class="smenu-action__results  js-smenu-action__results" style="-webkit-box-sizing: border-box; box-sizing: border-box;">504 cars found</div>
                            <a href="https://www.carlist.my/cars-for-sale/toyota/86/malaysia" class="smenu-action__button  js-smenu-action__button  block  weight--semibold" style="-webkit-box-sizing: border-box; box-sizing: border-box; background-color: transparent; -webkit-transition: all 0.3s ease; transition: all 0.3s ease; color: #02aaee; cursor: pointer; text-decoration: none; font-family: bmwTypeNextWeb, Arial, Helvetica, sans-serif; font-style: normal; font-weight: 500; display: block;">
                                Show Result        </a>
                        </div>
                        <div class="smenu-alert  one-whole  fixed  bottom--left  soft  visuallyhidden--desk-wide  transition--default" data-no-result-message="No results for this range. <br>Please adjust the range to improve results." data-no-result-actions-class=".smenu-alert__actions--no-result" data-not-apply-message="<span class='visuallyhidden'>504 Toyota 86 Cars for Sale in Malaysia</span>Would you like to apply your changes?" data-not-apply-actions-class=".smenu-alert__actions--not-apply" style="-webkit-box-sizing: border-box; box-sizing: border-box; width: 100%; bottom: 0; left: 0; padding: 20px; position: fixed; -webkit-transition: all .3s ease; -o-transition: all .3s ease; transition: all .3s ease;">
                            <div class="smenu-alert__content" style="-webkit-box-sizing: border-box; box-sizing: border-box;">
                                <div class="smenu-alert__message" style="-webkit-box-sizing: border-box; box-sizing: border-box;">
                                    No results for this range. <br style="-webkit-box-sizing: border-box; box-sizing: border-box;">Please adjust the range to improve results.            </div>
                                <div class="smenu-alert__actions  smenu-alert__actions--not-apply  flexbox  visuallyhidden  text--uppercase" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: table; text-transform: uppercase; clip: rect(0 0 0 0); border: 0; height: 1px; margin: -1px; overflow: hidden; padding: 0; position: absolute; width: 1px;">
                                    <div class="flexbox__item  one-third" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: table-cell; vertical-align: middle; width: 33.333%;"><a href="#" class="btn  btn--full  js-smenu-alert--not-apply-btn-no" style="-webkit-box-sizing: border-box; box-sizing: border-box; -webkit-user-select: none; -moz-user-select: none; -ms-user-select: none; user-select: none; background-color: transparent; background: transparent; border: 1px solid #cfd6df; border-radius: 4px; color: #576a7f; cursor: pointer; display: inline-block; font-size: 13px; line-height: 34px; margin: 0; padding: 0 12px; position: relative; text-shadow: none; text-transform: capitalize; -webkit-transition: all .4s ease-out; -o-transition: all .4s ease-out; transition: all .4s ease-out; vertical-align: middle; white-space: nowrap; padding-left: 0; padding-right: 0; text-align: center; width: 100%; font-family: bmwTypeNextWeb, Arial, Helvetica, sans-serif; font-style: normal; font-weight: 700; outline: none; text-decoration: none;">No</a>
                                    </div>
                                    <div class="one-third" style="-webkit-box-sizing: border-box; box-sizing: border-box; width: 33.333%;">&nbsp;</div>
                                    <div class="flexbox__item  one-third" style="-webkit-box-sizing: border-box; box-sizing: border-box; display: table-cell; vertical-align: middle; width: 33.333%;"><a href="https://www.carlist.my/cars-for-sale/toyota/86/malaysia" class="btn  btn--full  btn--active  js-smenu-action__button" style="-webkit-box-sizing: border-box; box-sizing: border-box; -webkit-user-select: none; -moz-user-select: none; -ms-user-select: none; user-select: none; background-color: transparent; background: transparent; border: 1px solid #cfd6df; border-radius: 4px; color: #576a7f; cursor: pointer; display: inline-block; font-size: 13px; line-height: 34px; margin: 0; padding: 0 12px; position: relative; text-shadow: none; text-transform: capitalize; -webkit-transition: all .4s ease-out; -o-transition: all .4s ease-out; transition: all .4s ease-out; vertical-align: middle; white-space: nowrap; padding-left: 0; padding-right: 0; text-align: center; width: 100%; font-family: bmwTypeNextWeb, Arial, Helvetica, sans-serif; font-style: normal; font-weight: 700; outline: none; text-decoration: none;">Yes</a>
                                    </div>
                                </div>
                                <div class="smenu-alert__actions  smenu-alert__actions--no-result  text--uppercase" style="-webkit-box-sizing: border-box; box-sizing: border-box; text-transform: uppercase;">
                                    <a class="smenu-alert__dismiss  block" style="-webkit-box-sizing: border-box; box-sizing: border-box; background-color: transparent; -webkit-transition: all 0.3s ease; transition: all 0.3s ease; cursor: pointer; color: inherit; text-decoration: none; font-family: bmwTypeNextWeb, Arial, Helvetica, sans-serif; font-style: normal; font-weight: 700; display: block;">
                                        Ok, Got it                </a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="sorts  sorts--mobile  transition--default  hidden  js-mobile-sort">
                        <div class="sorts__content  transition--default">
                            <div class="sorts__head">
                                <div class="flexbox">
                                    <div class="flexbox__item  tight  action  action--left   visuallyhidden--palm"><span class="icon  icon--md-close  icon--medium  js-mobile-sort__trigger"></span></div>
                                    <div class="flexbox__item  weight--semibold">Sort</div>
                                    <div class="flexbox__item  tight  action  action--right  visuallyhidden--lap-and-up"><span class="js-mobile-sort__trigger">Cancel</span></div>
                                </div>
                            </div>
                            <div class="sorts__body">
                                <ul class="sorts__menu">
                                    <li class="li--selected">
                                        <a href="https://www.carlist.my/cars-for-sale/toyota/86/malaysia?sort=best.match" data-do-url="true" data-do-function="mobileSortClose" class="js-smenu__do-ajaxify">
                                            Best Match                        </a>
                                    </li>
                                    <li class="">
                                        <a href="https://www.carlist.my/cars-for-sale/toyota/86/malaysia?sort=modification_date_search.desc" data-do-url="true" data-do-function="mobileSortClose" class="js-smenu__do-ajaxify">
                                            Latest Updated                        </a>
                                    </li>
                                    <li class="">
                                        <a href="https://www.carlist.my/cars-for-sale/toyota/86/malaysia?sort=price.asc" data-do-url="true" data-do-function="mobileSortClose" class="js-smenu__do-ajaxify">
                                            Price: Low to High                        </a>
                                    </li>
                                    <li class="">
                                        <a href="https://www.carlist.my/cars-for-sale/toyota/86/malaysia?sort=price.desc" data-do-url="true" data-do-function="mobileSortClose" class="js-smenu__do-ajaxify">
                                            Price: High to Low                        </a>
                                    </li>
                                    <li class="">
                                        <a href="https://www.carlist.my/cars-for-sale/toyota/86/malaysia?sort=year.desc" data-do-url="true" data-do-function="mobileSortClose" class="js-smenu__do-ajaxify">
                                            Year: New to Old                        </a>
                                    </li>
                                    <li class="">
                                        <a href="https://www.carlist.my/cars-for-sale/toyota/86/malaysia?sort=year.asc" data-do-url="true" data-do-function="mobileSortClose" class="js-smenu__do-ajaxify">
                                            Year: Old to New                        </a>
                                    </li>
                                    <li class="">
                                        <a href="https://www.carlist.my/cars-for-sale/toyota/86/malaysia?sort=mileage.asc" data-do-url="true" data-do-function="mobileSortClose" class="js-smenu__do-ajaxify">
                                            Mileage: Low to High                        </a>
                                    </li>
                                    <li class="">
                                        <a href="https://www.carlist.my/cars-for-sale/toyota/86/malaysia?sort=mileage.desc" data-do-url="true" data-do-function="mobileSortClose" class="js-smenu__do-ajaxify">
                                            Mileage: High to Low                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </nav>
                <div class="listings__fixed-right  grid__item  palm-one-whole  float--right">
                    <div class="grid">
                        <section id="classified-listings-result" class="listings__section  grid__item  seven-tenths  portable-one-whole  palm-one-whole" style="width:100%">

                            <div class="listings__ad-unit  text--center  push--ends  desk-flush--top">

                                <!-- listings_strip_banner_one -->
                                <div id="div-gpt-ad-1455072887849-0">
                                </div>
                            </div>


                            <div class="guides  box  hard  push--bottom  cf">
                                {{--<div class="guide__hot-deal  float--left  palm-one-whole  js-ajax-links">--}}
                                    {{--<div class="flexbox  push-quarter--ends">--}}
                                        {{--<div class="flexbox__item  guide__icon   soft-half--left  soft-quarter--right  text--center"><i class="icon  icon--fire"></i></div>--}}
                                        {{--<div class="flexbox__item  guide__label  soft-half--right">Hot deals</div>--}}
                                        {{--<div class="flexbox__item  guide__input  soft-half--right  tight">--}}
                                            {{--<a href="/cars-for-sale/toyota/86/malaysia?hotdeal=true" class="toggle  float--left">--}}
                                                {{--<div class="toggle__circle  radius--circle  inline--block  valign--top  float--left"></div>--}}
                                                {{--<div class="toggle__label  no--overflow  text--center  text--uppercase  line--inherit">--}}
                                                    {{--<div class="label-on">On</div>--}}
                                                    {{--<div class="label-off">Off</div>--}}
                                                {{--</div>--}}
                                            {{--</a>--}}
                                        {{--</div>--}}
                                    {{--</div>--}}
                                {{--</div>--}}

                                <hr class="rule  muted  flush  float--left  one-whole  visuallyhidden--desk">

                                <nav class="guide__sorts  float--right  portable-one-whole">
                                    <div class="flexbox  flexbox--auto  push-quarter--ends  palm-one-whole">
                                        <div class="flexbox__item  guide__label">
                                            <div class="flexbox">
                                                <div class="flexbox__item  guide__icon   soft-half--left  soft-quarter--right  text--center"><i class="icon  icon--sort  text--muted"></i></div>
                                                <div class="flexbox__item  soft-half--right">Sort by:</div>
                                            </div>
                                        </div>

                                        <div class="flexbox__item  guide__input  soft-half--right">
                                            <div class="selectize-input--borderless  selectize-input--paddingless  selectize-input--visibletext  selectize--disable-input  selectize--tight  selectize--link  selectize--dropdown-flexible  selectize--dropdown-right  selectize--dropdown-gapped">
                                                <select class="js-selectize  js-listing-sort  listings__sort   js-ajax   selectized" data-selected="" data-placeholder="Best Match" data-readonly="true" tabindex="-1" style="display: none;"><option value="best.match" selected="selected">Best Match</option></select><div class="selectize-control js-selectize js-listing-sort listings__sort js-ajax single"><div class="selectize-input items input-readonly full has-options has-items"><div data-value="best.match" class="item">Best Match</div><input type="text" autocomplete="off" tabindex="" readonly="readonly" style="width: 4px;"></div><div class="selectize-dropdown single js-selectize js-listing-sort listings__sort js-ajax" style="display: none; width: 95px; top: 36px; left: 0px;"><div class="selectize-dropdown-content"></div></div></div>
                                            </div>
                                        </div>
                                    </div>
                                </nav>
                            </div>



                            <div class="masthead  flexbox  push--bottom">
                                <div class="flexbox__item">
                                    <h1 class="headline  delta  flush">504 Toyota 86 Cars for Sale in Malaysia</h1>
                                </div>
                            </div>

                            {{--<div class="tabs  tabs--sellertype  flexbox  js-ajax-links">--}}
                                {{--<a class="tabs__item  flexbox__item  tight  soft-half cycle-pager-active" href="https://www.carlist.my/cars-for-sale/toyota/86/malaysia">All</a>--}}
                                {{--<a class="tabs__item  flexbox__item  tight  soft-half " href="https://www.carlist.my/cars-for-sale/toyota/86/malaysia?profile_type=Private">Private</a>--}}
                                {{--<a class="tabs__item  flexbox__item  tight  soft-half " href="https://www.carlist.my/cars-for-sale/toyota/86/malaysia?profile_type=Dealer">Dealer</a>--}}

                                {{--<div class="flexbox__item">&nbsp;</div>--}}

                                {{--<div class="flexbox__item  tight  visuallyhidden--desk">--}}
                                    {{--<div class="guide__hot-deal  float--left  palm-one-whole  js-ajax-links">--}}
                                        {{--<div class="flexbox  push-quarter--ends">--}}
                                            {{--<div class="flexbox__item  guide__icon   soft-half--left  soft-quarter--right  text--center"><i class="icon  icon--fire"></i></div>--}}
                                            {{--<div class="flexbox__item  guide__label  soft-half--right">Hot deals</div>--}}
                                            {{--<div class="flexbox__item  guide__input  soft-half--right  tight">--}}
                                                {{--<a href="/cars-for-sale/toyota/86/malaysia?hotdeal=true" class="toggle  float--left">--}}
                                                    {{--<div class="toggle__circle  radius--circle  inline--block  valign--top  float--left"></div>--}}
                                                    {{--<div class="toggle__label  no--overflow  text--center  text--uppercase  line--inherit">--}}
                                                        {{--<div class="label-on">On</div>--}}
                                                        {{--<div class="label-off">Off</div>--}}
                                                    {{--</div>--}}
                                                {{--</a>--}}
                                            {{--</div>--}}
                                        {{--</div>--}}
                                    {{--</div>--}}
                                {{--</div>--}}
                            {{--</div>--}}

                            <!-- rating status show when filter model -->

                            <!-- show this bar when user filter model, other hide it -->
                            {{--<div class="listing__rating-bar  flex  box  flex--justify-between  flex--items-center  push--top">--}}
                                {{--<div class="rating__title">--}}
                                    {{--Overall Rating <span class="visuallyhidden--palm">for this model</span> <span class="micro">(7 Reviews)</span>--}}
                                {{--</div>--}}

                                {{--<div class="flex">--}}
                                    {{--<!-- rating star mobile  -->--}}
                                    {{--<div class="rating--star-mobile  visuallyhidden--lap-and-up  push-quarter--right">--}}
                                        {{--<i class="icon  icon--star  filled"></i>--}}
                                    {{--</div>--}}
                                    {{--<!-- rating point -->--}}
                                    {{--<span class="rating--number  soft-quarter--right">4.6</span>--}}
                                    {{--<!-- rating star -->--}}
                                    {{--<div class="rating--star  visuallyhidden--palm">--}}
                                        {{--<!-- add filled for color -->--}}
                                        {{--<i class="icon  icon--star  filled"></i>--}}
                                        {{--<i class="icon  icon--star  filled"></i>--}}
                                        {{--<i class="icon  icon--star  filled"></i>--}}
                                        {{--<i class="icon  icon--star  filled"></i>--}}
                                        {{--<i class="icon  icon--star  filled"></i>--}}
                                    {{--</div>--}}
                                    {{--<!-- link to modal userreview -->--}}
                                    {{--<!-- mobile -->--}}
                                    {{--<a href="javascript:void(0)" id="review-popup" class="epsilon  soft-half--left  visuallyhidden--lap-and-up  js-bpopup" data-target=".modal--userreview">»</a>--}}
                                    {{--<!-- desktop -->--}}
                                    {{--<a href="javascript:void(0)" id="review-popup" class="soft-half--left  visuallyhidden--palm  js-bpopup" data-target=".modal--userreview">--}}
                                        {{--View More        </a>--}}
                                    {{--<input type="hidden" name="make" value="Toyota">--}}
                                    {{--<input type="hidden" name="model" value="86">--}}
                                    {{--<input type="hidden" name="current_page" value="1">--}}
                                    {{--<input type="hidden" name="last_page" value="2">--}}
                                {{--</div>--}}
                            {{--</div>--}}

                            @if(count($prods)>0)
                                @foreach($prods as $prod)
                            <article class="listing  listing--card  box  relative  push--top  js--listing  js--multi-lead listing--review" id="listing_8113640" data-listing-id="8113640" data-title="2017 Toyota 86 GT FACELIFT 13000KM True Mileage" data-display-title="2017 Toyota 86 2.0 GT Coupe" data-url="https://www.carlist.my/recon-cars/2017-toyota-86-gt-facelift-13000km-true-mileage/8113640" data-price="ʯʰ˝ˌˋ˅ˑˍˍˍ" data-price-raw="ˌˋ˅ˍˍˍ" data-installment="RM 2,178/month" data-phone="ˍˌˋːˏˉˉˉˏˌˏ" data-phone-whatsapp="ˍˌˋːˏˉˉˉˏˌˏ" data-default-whatsapp-text="Hi%2C%20I%20saw%20your%20car%20on%20Carlist.my%20and%20I%20would%20like%20to%20know%20more%20about%202017%20Toyota%2086%20GT%20FACELIFT%2013000KM%20True%20Mileage%20%28RM%20168%2C000%29.%20Thanks.%20https%3A%2F%2Fwww.carlist.my%2Frecon-cars%2F2017-toyota-86-gt-facelift-13000km-true-mileage%2F8113640" data-default-line-text="I am interested in your car on Carlist.my - 2017 Toyota 86 GT FACELIFT 13000KM True Mileage (RM 168,000). https://www.carlist.my/recon-cars/2017-toyota-86-gt-facelift-13000km-true-mileage/8113640." data-phones="ʆ˟ˍˌˋːˏˉˉˉˏˌˏ˟ˇʆ˟ʉʄʍʘ˟ˇ˟ʊʕʜʉʎʢʜʍʍ˟ˑ˟ʓʈʐʟʘʏ˟ˇ˟ˍˌˋːˏˉˉˉˏˌˏ˟ʀʀ" data-line-id="" data-line-numbers="ʆ˟˟ˇʆ˟ʉʄʍʘ˟ˇ˟ʜʚʘʓʉ˟ˑ˟ʓʜʐʘ˟ˇ˟ʾʕʒʒʓʚ˝ʪʜʔ˝ʭʔʓ˟ˑ˟ʓʈʐʟʘʏ˟ˇ˟˟ˑ˟ʑʔʓʘʢʓʈʐʟʘʏ˟ˇ˟˟ʀʀ" data-compare-image="https://img1.icarcdn.com/0463118/thumb-l_recon-car-carlist-toyota-86-gt-coupe-malaysia_000000463118_81226e7f_45e0_4e1a_85ae_9c5612120116.jpg?smia=xTM" data-image-src="https://img1.icarcdn.com/0463118/main-m_recon-car-carlist-toyota-86-gt-coupe-malaysia_000000463118_81226e7f_45e0_4e1a_85ae_9c5612120116.jpg?smia=xTM" data-make="Toyota" data-model="86" data-year="2017" data-mileage="12500" data-transmission="Automatic" data-ad-type="Recon" data-variant="GT" data-listing-status="Published" data-location="ʮʘʑʜʓʚʒʏ" data-area="ʭʘʉʜʑʔʓʚ˝ʷʜʄʜ" data-city="" data-seller-username="ʉʘʏʜʎʎʜʏʔˏ" data-seller-name="ʾʕʒʒʓʚ˝ʪʜʔ˝ʭʔʓ" data-video="" data-isbmw="" data-isvolvo="" data-seller-id="19990604-0b35-4924-b8f2-30b9f80c21bf" data-profile-type="ʮʜʑʘʎ˝ʼʚʘʓʉ" data-profile-id="0c0eff67-aa42-4aa0-99f0-c8c5965e9bc5" data-hot-deal="false" data-listing-trusted="true" data-view-store="true" data-chat-id="0" data-country-code="my" data-vehicle-type="car" data-newctr-callus="Call Now" data-newctr-exchat-detection="whatsApp_Url" data-newctr-chat-now="WhatsApp Now">
                                <div class="grid  grid--full  cf">
                                    <header class="listing__header">
                                        <div class="grid__item  hard  three-tenths   palm-one-half">
                                            <a href="{{ route('product', $prod->slug) }}" class="d-block">
                                                <img
                                                        class="img-fit lazyload mx-auto h-140px h-md-210px"
                                                        src="{{ static_asset('assets/img/placeholder.jpg') }}"
                                                        data-src="{{ uploaded_asset($prod->thumbnail_img) }}"
                                                        alt="{{  $prod->getTranslation('name')  }}"
                                                        onerror="this.onerror=null;this.src='{{ static_asset('assets/img/placeholder.jpg') }}';"
                                                >
                                            </a>

                                            <div class="listing__tools  action-items  push-half--top  visuallyhidden--palm">
                                                {{--<label for="compare_8113640" class="action-items__item  checkbox  soft--left">--}}
                                                    {{--<input value="8113640" class="visuallyhidden  js-toggle-compare-basket" autocomplete="off" id="compare_8113640" type="checkbox" name="compare8113640">--}}
                                                    {{--<span class="icon  icon--md-done"></span><span class="push-quarter--left">Compare</span>--}}
                                                {{--</label>--}}

                                                {{--<a href="https://dealer.carlist.my/default.aspx?is_private=true&amp;return_url=https%3A%2F%2Fwww.carlist.my%2Fcars-for-sale%2Ftoyota%2F86%2Fmalaysia" data-save="Save" data-saved="Saved" class="action-items__item  action-items__item--8113640  action-items__item--save  push-quarter--left" data-ga-click-type="cad-sav" data-ga-click-id="8113640" data-auth="saveCar">--}}
                                                    {{--<i class="icon  icon--heart-empty  icon--flexible  push-quarter--right  valign--top"></i><span>Save</span>--}}
                                                {{--</a>--}}

                                                {{--<div class="absolute-top-right aiz-p-hov-icon">--}}
                                                <a class="btn btn-primary" href="javascript:void(0)" onclick="showAddToCartModal({{ $prod->id }})" data-toggle="tooltip" data-title="{{ translate('Add to cart') }}" data-placement="left">
                                                    Add to Cart
                                                </a>
                                                {{--</div>--}}
                                            </div>
                                        </div>

                                        {{--<div class="grid__item  hard  three-tenths  palm-one-half  float--right">--}}
                                            {{--<!-- SPONSORS -->--}}
                                            {{--<div class="listing__label  listing__label--premium  space--nowrap  no--overflow">--}}
                                                {{--<i class="icon  icon--premium  valign--top  push-quarter--right"></i><span class="visuallyhidden--small">Featured</span>--}}
                                            {{--</div>--}}


                                            {{--<div class="listing__rating  flex  flex--justify-between  soft-quarter--ends  soft-half--sides   push-quarter--bottom  milli">--}}
                                                {{--<div class="flex  text--truncate">--}}
                                                    {{--<i class="icon  muted  icon--car-front  icon--secondary   push-quarter--right"></i>--}}
                                                    {{--<div class="listing__rating-model text--truncate  soft-quartter--right">Toyota 86</div>--}}
                                                {{--</div>--}}
                                                {{--<div class="space--nowrap"><i class="icon  icon--star"></i> 4.6</div>--}}
                                            {{--</div>--}}
                                            {{--<div class="listing__specs  soft-quarter--ends  soft-half--sides  milli">--}}
                                                {{--<div class="item  push-quarter--ends  soft--right  push-quarter--right">--}}
                                                    {{--<i class="icon  icon--secondary  muted  valign--top  push-quarter--right  icon--meter"></i>10 - 15K KM    </div>--}}
                                                {{--<div class="item  push-quarter--ends">--}}
                                                    {{--<i class="icon  icon--secondary  muted  valign--top  push-quarter--right  icon--transmission"></i>Automatic    </div>--}}
                                                {{--<div class="item  push-quarter--ends">--}}
                                                    {{--<i class="icon  icon--secondary  muted  valign--top  push-quarter--right  icon--location"></i>Selangor    </div>--}}
                                                {{--<div class="item  push-quarter--ends  listing__spec--dealer">--}}
                                                    {{--<i class="icon  icon--secondary  muted  valign--top  push-quarter--right  icon--user-formal"></i>Sales Agent                                            <span class="flyout  listing__badge  listing__badge--trusted-seller  inline--block  valign--top  push-quarter--left">--}}
                            {{--<i class="icon  icon--thumb-up"></i>--}}
                                            {{--<span class="flyout__content  flyout__content--tip  visuallyhidden--portable">This 'Trusted Dealer' has a proven track record of upholding the best car selling practices certified by Carlist.my</span>--}}
                                        {{--</span>--}}


                                                    {{--<!-- used car -->--}}


                                                    {{--<!-- SPONSOR -->--}}

                                                {{--</div>--}}
                                            {{--</div>--}}

                                            {{--<div class="visuallyhidden--palm">--}}

                                                {{--<div class="contact--option  flexbox">--}}
                                                    {{--<div class="flexbox__item">--}}
                                                        {{--<a href="#" class="listing__ctr  btn  btn--large  btn--primary  one-whole  btn--large  js-ctr-button  js-contact-seller  js-show-top  js-contact-seller--jump-phone" data-listing-id="8113640" data-ad-type="Recon" data-seller-username="ʉʘʏʜʎʎʜʏʔˏ" data-dmp-location="search_result" data-ga-click-type="cad-num" data-ga-click-ad-products="featured" data-ga-click-id="8113640" data-ga-click-seller="19990604-0b35-4924-b8f2-30b9f80c21bf" data-ga-event="ctr_call_lvl_1" data-phone-only="" data-car-info="Toyota|86|Coupe" rel="nofollow" tml-c="action" tml-a="ctr_click" tml-sn="listings_index" tml-si="8113640" tml-sl="_ctr_button">--}}
                                                            {{--<!-- Show icon call when only Call button -->--}}
                                                            {{--<span class="listing__call">Contact</span>--}}
                                                        {{--</a>--}}
                                                    {{--</div>--}}
                                                    {{--<div class="flexbox__item  fifth-eights  soft-quarter--left">--}}
                                                        {{--<a href="#" class="btn btn--app btn--large  text--white btn--large btn--full js-ctr-button js-contact-seller js-show-top js-contact-seller--jump-whatsapp" data-listing-id="8113640" data-ad-type="Recon" data-seller-username="ʉʘʏʜʎʎʜʏʔˏ" data-dmp-location="search_result" data-ga-click-type="cad-num" data-ga-click-ad-products="featured" data-ga-click-id="8113640" data-ga-click-seller="19990604-0b35-4924-b8f2-30b9f80c21bf" data-ga-event="ctr_whatsapp_lvl_1" data-phone-only="" data-car-info="Toyota|86|Coupe" rel="nofollow" tml-c="action" tml-a="ctr_click" tml-sn="listings_index" tml-si="8113640" tml-sl="_ctr_button">--}}
                                                            {{--<img class="valign--middle  icon  icon--whatsapp  icon--20  visuallyhidden--palm" style="width: 15px;" src="//common.icarcdn.com/images/icon--whatsapp.svg">--}}
                                                            {{--<span>WhatsApp</span>--}}
                                                        {{--</a>--}}
                                                    {{--</div>--}}
                                                {{--</div>--}}
                                            {{--</div>--}}
                                        {{--</div>--}}
                                    </header>
                                    <div class="listing__content  grid__item  soft-half--sides  four-tenths  palm-one-whole relative">
                                        <!-- BMW mobile  -->

                                        <!-- Volvo mobile  -->

                                        <!-- BenzBKK mobile  -->

                                        <!-- Wsmart mobile  -->


                                        <span class="nano  absolute  top--right  soft-quarter  visuallyhidden--lap-and-up">
                        </span>
                                        <div class="listing__tools  action-items  push-half--bottom  visuallyhidden--lap-and-up">
                                            {{--<label for="compare_8113640" class="action-items__item  checkbox  soft--left">--}}
                                                {{--<input value="8113640" class="visuallyhidden  js-toggle-compare-basket" autocomplete="off" id="compare_8113640" type="checkbox" name="compare8113640">--}}
                                                {{--<span class="icon  icon--md-done"></span><span class="push-quarter--left">Compare</span>--}}
                                            {{--</label>--}}

                                            {{--<a href="https://dealer.carlist.my/default.aspx?is_private=true&amp;return_url=https%3A%2F%2Fwww.carlist.my%2Fcars-for-sale%2Ftoyota%2F86%2Fmalaysia" data-save="Save" data-saved="Saved" class="action-items__item  action-items__item--8113640  action-items__item--save  push-quarter--left" data-ga-click-type="cad-sav" data-ga-click-id="8113640" data-auth="saveCar">--}}
                                                {{--<i class="icon  icon--heart-empty  icon--flexible  push-quarter--right  valign--top"></i><span>Save</span>--}}
                                            {{--</a>--}}

                                            <a class="btn btn-primary" href="javascript:void(0)" onclick="showAddToCartModal({{ $prod->id }})" data-toggle="tooltip" data-title="{{ translate('Add to cart') }}" data-placement="left">
                                                Add to Cart
                                            </a>
                                        </div>

                                        <h2 class="listing__title  epsilon  flush">
                                            <a class="ellipsize  js-ellipsize-text" href="https://www.carlist.my/recon-cars/2017-toyota-86-gt-facelift-13000km-true-mileage/8113640" data-ellipsize-length="67" data-ga-show-type="cad-lis" data-ga-show-id="8113640">
                                                {{ $prod->name }}</a>
                                        </h2>

                                        <div class="listing__excerpt  milli  text--muted  push-quarter--ends" x-ms-format-detection="none" style="font-size: 16px;">
                                            {!! Str::limit($prod->description, 500) !!}</div>
                                        <div class="grid  push-half--top">
                                            <div class="grid__item  one-whole  push-half--bottom  flex">
                                                <div class="two-thirds">

                                                    {{--<div class="listing__installment" data-show-installment="true">--}}
                                                       {{--sda                  </div>--}}
                                                    <div class="listing__price  delta  weight--bold" x-ms-format-detection="none"> RM {{$prod->unit_price  }}</div>
                                                </div>
                                            </div>
                                            <div class="grid__item  palm-one-whole  visuallyhidden--lap-and-up">

                                                <div class="contact--option  flexbox">
                                                    <div class="flexbox__item">
                                                        <a href="#" class="listing__ctr  btn  btn--large  btn--primary  one-whole  btn--large  js-ctr-button  js-contact-seller  js-show-top  js-contact-seller--jump-phone" data-listing-id="8113640" data-ad-type="Recon" data-seller-username="ʉʘʏʜʎʎʜʏʔˏ" data-dmp-location="search_result" data-ga-click-type="cad-num" data-ga-click-ad-products="featured" data-ga-click-id="8113640" data-ga-click-seller="19990604-0b35-4924-b8f2-30b9f80c21bf" data-ga-event="ctr_call_lvl_1" data-phone-only="" data-car-info="Toyota|86|Coupe" rel="nofollow" tml-c="action" tml-a="ctr_click" tml-sn="listings_index" tml-si="8113640" tml-sl="_ctr_button">
                                                            <!-- Show icon call when only Call button -->
                                                            <span class="listing__call">Contact</span>
                                                        </a>
                                                    </div>
                                                    <div class="flexbox__item  fifth-eights  soft-quarter--left">
                                                        <a href="#" class="btn btn--app btn--large  text--white btn--large btn--full js-ctr-button js-contact-seller js-show-top js-contact-seller--jump-whatsapp" data-listing-id="8113640" data-ad-type="Recon" data-seller-username="ʉʘʏʜʎʎʜʏʔˏ" data-dmp-location="search_result" data-ga-click-type="cad-num" data-ga-click-ad-products="featured" data-ga-click-id="8113640" data-ga-click-seller="19990604-0b35-4924-b8f2-30b9f80c21bf" data-ga-event="ctr_whatsapp_lvl_1" data-phone-only="" data-car-info="Toyota|86|Coupe" rel="nofollow" tml-c="action" tml-a="ctr_click" tml-sn="listings_index" tml-si="8113640" tml-sl="_ctr_button">
                                                            <img class="valign--middle  icon  icon--whatsapp  icon--20  visuallyhidden--palm" style="width: 15px;" src="//common.icarcdn.com/images/icon--whatsapp.svg">
                                                            <span>WhatsApp</span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>



                                        <div>
                                        </div>
                                        <div class="visuallyhidden--palm">
                                        </div>

                                        <!-- BMW desktop -->

                                        <!-- Volvo desktop -->

                                        <!-- BenzBKK desktop -->


                                        <!-- Wsmart desktop -->
                                    </div>
                                </div>
                            </article>


                                @endforeach
                            @else
                                <h4 class="card-title">No data found!</h4>
                            @endif
                            <br>

                            <!--  userreview -->
                            <div class="modal  modal--default  modal--userreview  visuallyhidden" id="user-reviews-content">
                                <div class="modal__head  flexbox">
                                    <div class="flexbox__item  modal__title">
                                        User Review of <span id="make-reviews"></span> <span id="model-reviews"></span>        </div>
                                    <div class="flexbox__item  modal__destroy  weight--light  b-close">×</div>
                                </div>
                                <div class="modal__body">
                                    <div class="user-review-overall" id="user-review-overall">

                                    </div>
                                    <!-- user results -->
                                    <div class="user-review-results  soft--ends" id="user-reviews-results">

                                    </div>
                                    <!-- loading screen -->
                                    <div class="loading-screen  c-preloader" style="position: absolute;z-index: 9999999;">
                                        <div class="c-preloader__content">
                                            <div class="c-preloader__spinner">
                                                <div class="bounce  bounce--one"></div>
                                                <div class="bounce  bounce--two"></div>
                                                <div class="bounce  bounce--three"></div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div class="modal  modal--default  modal--userreview_report  fill--white  visuallyhidden  js-review-report">
                                <div class="modal__head  flexbox" id="report-reviews-popup">
                                    <div class="flexbox__item  modal__title">Report</div>
                                    <div class="flexbox__item  modal__destroy  weight--light  b-close">×</div>
                                </div>
                                <div class="modal__body  soft--ends">
                                    <div class="report-form-body">
                                        <h2 class="epsilon">Tell us why do you want to report this review?</h2>
                                        <p>This won't be shared with the lost</p>
                                        <ul class="userreview_report-listing">
                                            <li class="soft-quarter--ends">
                                                <label for="report1" class="checkbox  checkbox--circle">
                                                    <input type="hidden" name="review_id" value="">
                                                    <input type="radio" name="report" id="report1" value="aggressive_language" class="visuallyhidden">
                                                    <span class="icon  icon--md-done"></span>
                                                    This review contains aggressive or discriminatory language
                                                </label>
                                            </li>
                                            <li class="soft-quarter--ends">
                                                <label for="report2" class="checkbox  checkbox--circle">
                                                    <input type="radio" name="report" id="report2" value="false_info" class="visuallyhidden" checked="">
                                                    <span class="icon  icon--md-done"></span>
                                                    This review contains false information
                                                </label>
                                            </li>
                                            <li class="soft-quarter--ends">
                                                <label for="report3" class="checkbox  checkbox--circle">
                                                    <input type="radio" name="report" id="report3" value="spam" class="visuallyhidden">
                                                    <span class="icon  icon--md-done"></span>
                                                    This review is a spam                    </label>
                                            </li>
                                        </ul>

                                        <div class="text--center"><a href="javascript:void(0)" class="btn btn--primary soft--sides disabled" id="userreview-report">Submit</a></div>
                                    </div>
                                    <div class="report-done  text--center  visuallyhidden">
                                        <div class="icon--md-done  push--ends"></div>
                                        <h2 class="epsilon">Thank you for the feedback!</h2>
                                        <p>We will appropriate action towards the review.</p>
                                    </div>
                                </div>
                            </div>
                        </section>
                        {{--<aside class="listings__side  grid__item  three-tenths  palm-one-whole  portable-one-whole">--}}

                            {{--<div class="push--bottom">--}}
                                {{--<h2 class="headline  epsilon">Recently viewed</h2>--}}

                                {{--<article class="media  media--listing  push-half--top">--}}
                                    {{--<a class="media__img  one-third  push-half--right  relative" href="https://www.carlist.my/used-cars/2015-2020-toyota-86-2-0-coupe-gt-a-like-new-car-trd-sport-1-lady-owner-well-maintained-ferrari-red-color/8022075">--}}
                                        {{--<img class="listing__img  valign--top" src="//common.icarcdn.com/images/placeholder.png" alt="2015/2020 Toyota 86 2.0 Coupe GT (A) Like New Car TRD Sport 1 Lady Owner Well Maintained Ferrari Red Color" data-src="https://img1.icarcdn.com/5702208/thumb-l_used-car-carlist-toyota-86-coupe-malaysia_000005702208_233a02d9_d7a0_4720_b12e_a3adedf7db87.jpeg?smia=xTM" data-amp-height="81" data-amp-width="108">        </a>--}}
                                    {{--<div class="media__body">--}}
                                        {{--<h3 class="media__title  zeta  push-quarter--bottom">--}}
                                            {{--<a href="https://www.carlist.my/used-cars/2015-2020-toyota-86-2-0-coupe-gt-a-like-new-car-trd-sport-1-lady-owner-well-maintained-ferrari-red-color/8022075">2015 Toyota 86 2.0 Coupe</a>--}}
                                        {{--</h3>--}}

                                        {{--<div class="media__price">--}}

                                            {{--<div class="listing__installment" data-show-installment="true">--}}
                                                {{--RM 1,761 / month                    </div>--}}
                                            {{--<div class="listing__price  delta  weight--bold" x-ms-format-detection="none">RM 135,800</div>--}}
                                        {{--</div>--}}
                                    {{--</div>--}}
                                {{--</article>--}}


                            {{--</div>--}}

                            {{--<!-- listings_half_page -->--}}
                            {{--<div class="ad_unit--side  push--ends  text--center" id="div-gpt-ad-1455072567883-0">--}}
                            {{--</div>--}}

                            {{--<!-- Hide Calculator for Mcycle Search Result -->--}}
                            {{--<div class="listing__section--calculator  soft-half  push--bottom  fill--grey  js-tools">--}}

                                {{--<!--  Normal Head -->--}}
                                {{--<h2 class="headline  epsilon  listing__section__head  push-half--bottom  ">Financial calculator</h2>--}}
                                {{--<div class="tool-container  box  hard  ">--}}
                                    {{--<div class="tool  tool--loan">--}}
                                        {{--<header class="tool__headline  toggler  flexbox  js-toggler" data-target=".js-loan-calculator">--}}
                                            {{--<div class="flexbox__item">--}}
                                                {{--<div class="tool__title">Car loan monthly installment *</div>--}}
                                                {{--<span class="tool__price  gamma  weight--bold">    RM <span class="raw-price">1,292.54</span>--}}
{{--</span>--}}
                                            {{--</div>--}}
                                            {{--<div class="flexbox__item  text--right">--}}
                                                {{--<i class="toggler__icon  icon  icon--medium  icon--down-open"></i>--}}
                                            {{--</div>--}}
                                        {{--</header>--}}
                                        {{--<div id="loan_calculator" class="js-loan-calculator  tool_body  push-half--top  visuallyhidden">--}}
                                            {{--<!-- for car listing -->--}}
                                            {{--<div id="tool_loan" class="tool__form  tool__form--calculator" data-thousand-separator=",">--}}
                                                {{--<div class="form-group  push--bottom">--}}
                                                    {{--<label class="tool__label  field__label">--}}
                                                        {{--Vehicle Price            <span class="flyout  tool__help  visuallyhidden--portable">--}}
                {{--<i class="icon  icon--question-circle  valign--top"></i>--}}
                {{--<span class="flyout__content  flyout__content--tip">The selling price of the vehicle you intend to purchase.</span>--}}
            {{--</span>--}}
                                                    {{--</label>--}}
                                                    {{--<input class="input  one-whole  js-calculate-loan" id="loan_price" name="price" type="text" value="99700">--}}
                                                {{--</div>--}}

                                                {{--<div class="form-group  push--bottom  js-error-deposit">--}}
                                                    {{--<label class="tool__label  field__label">--}}
                                                        {{--Deposit Amount            <span class="flyout  tool__help  visuallyhidden--portable">--}}
                {{--<i class="icon  icon--question-circle  valign--top"></i>--}}
                {{--<span class="flyout__content  flyout__content--tip">The amount of money you intend to pay on your own that is not covered by the loan you will be taking from a bank.</span>--}}
            {{--</span>--}}
                                                    {{--</label>--}}
                                                    {{--<input class="input  one-whole  js-calculate-loan" id="loan_deposit" name="deposit" type="text" value="9970">--}}
                                                    {{--<div class="field--error__message  milli  push-quarter--ends  hidden  js-form-error" role="alert">Price &amp; Deposit must be numeric, greater than 0 and Deposit amount must be less than the vehicle price</div>--}}
                                                {{--</div>--}}

                                                {{--<div class="form-group  push--bottom  js-error-interest">--}}
                                                    {{--<label class="tool__label  field__label">--}}
                                                        {{--Bank Rates            <span class="flyout  tool__help  visuallyhidden--portable">--}}
                {{--<i class="icon  icon--question-circle  valign--top"></i>--}}
                {{--<span class="flyout__content  flyout__content--tip">The interest rate on the loan that is being charged to you by the bank.</span>--}}
            {{--</span>--}}
                                                    {{--</label>--}}
                                                    {{--<input class="input  one-whole  js-calculate-loan" id="loan_interest" name="interest" type="text" data-max-interest="15" value="3">--}}
                                                    {{--<div class="field--error__message  milli  push-quarter--ends  hidden  js-form-error" role="alert">Interest rate must be numeric and between 1 to 15</div>--}}
                                                {{--</div>--}}

                                                {{--<div class="form-group  push--bottom  js-error-period">--}}
                                                    {{--<label class="tool__label  field__label">--}}
                                                        {{--Repayment Period            <span class="flyout  tool__help  visuallyhidden--portable">--}}
                {{--<i class="icon  icon--question-circle  valign--top"></i>--}}
                {{--<span class="flyout__content  flyout__content--tip">The duration (in years) that you have to pay off your loan to the bank in entirety.</span>--}}
            {{--</span>--}}
                                                    {{--</label>--}}
                                                    {{--<input class="input  one-whole  js-calculate-loan" id="loan_period" name="period" type="text" data-divider="1" data-decimal-point="2" data-max-period="15" value="7">--}}
                                                    {{--<div class="field--error__message  milli  push-quarter--ends  hidden  js-form-error" role="alert">Repayment period must be numeric and between 1 to 15 years</div>--}}
                                                {{--</div>--}}

                                                {{--<p class="flush--bottom">--}}
                                                    {{--<span>Car loan monthly installment* </span>--}}
                                                    {{--<span class="tool__price  weight--bold">    RM <span class="raw-price">1,292.54</span>--}}
{{--</span>--}}
                                                {{--</p>--}}
                                                {{--<div class="tool__footnotes  micro  push-half--top  soft-half--bottom">--}}
                                                    {{--* Please use this calculator as a guide only. All interest rates, amounts and terms are based on a personal simulation by you and your assumptions of same. The results in every case are approximate. Carlist.my does not guarantee its accuracy or applicability to your circumstances.</div>--}}

                                            {{--</div>--}}
                                        {{--</div>--}}
                                    {{--</div>--}}
                                {{--</div><!-- .tool-container -->--}}
                            {{--</div>--}}

                            {{--<!-- listings_mrec -->--}}
                            {{--<div class="ad_unit--side  push--bottom  text--center" id="div-gpt-ad-1456716300004-0">--}}
                            {{--</div>--}}

                            {{--<hr class="visuallyhidden  js-ad-portrait">--}}

                            {{--<div class="section--expert-reviews  push--ends  js-part-reviews">--}}
                                {{--<h2 class="headline  epsilon  push--bottom">Expert reviews</h2>--}}

                                {{--<article class="media  media--listing  box  push-half--top">--}}
                                    {{--<a href="https://www.carlist.my/new-car/toyota/2018/vellfire/40591" class="media__img  one-third  push-half--right">--}}
                                        {{--<img src="https://content.icarcdn.com/styles/thumbnail_small/s3/field/car-model/search/2016/toyota-vellfire-search_1.jpg?itok=xfTqdw3_" data-src="https://content.icarcdn.com/styles/thumbnail_small/s3/field/car-model/search/2016/toyota-vellfire-search_1.jpg?itok=xfTqdw3_" alt="2018 Toyota Vellfire" class="lazy-loaded">--}}
                                    {{--</a>--}}
                                    {{--<div class="media__body">--}}
                                        {{--<h3 class="new-car__title  zeta  flush"><a href="https://www.carlist.my/new-car/toyota/2018/vellfire/40591">2018 Toyota Vellfire</a>--}}
                                        {{--</h3>--}}
                                        {{--<div class="rating  rating--stars  rating--small  push-quarter--ends">--}}
                                            {{--<div class="stars">--}}
                                                {{--<i class="icon  icon--star"></i>--}}
                                                {{--<i class="icon  icon--star"></i>--}}
                                                {{--<i class="icon  icon--star"></i>--}}
                                                {{--<i class="icon  icon--star"></i>--}}
                                                {{--<i class="icon  icon--star"></i>--}}
                                            {{--</div>--}}

                                            {{--<div class="stars  stars--rating" style="width:80%">--}}
                                                {{--<i class="icon  icon--star"></i>--}}
                                                {{--<i class="icon  icon--star"></i>--}}
                                                {{--<i class="icon  icon--star"></i>--}}
                                                {{--<i class="icon  icon--star"></i>--}}
                                                {{--<i class="icon  icon--star"></i>--}}
                                            {{--</div>--}}
                                        {{--</div>--}}
                                        {{--<div class="new-car__price  zeta  weight--bold">From RM 345,200</div>--}}
                                    {{--</div>--}}
                                {{--</article>--}}
                                {{--<article class="media  media--listing  box  push-half--top">--}}
                                    {{--<a href="https://www.carlist.my/new-car/toyota/2018/sienta/40899" class="media__img  one-third  push-half--right">--}}
                                        {{--<img src="https://content.icarcdn.com/styles/thumbnail_small/s3/field/car-model/search/2016/toyota-sienta-search.jpg?itok=sspCMPZ5" data-src="https://content.icarcdn.com/styles/thumbnail_small/s3/field/car-model/search/2016/toyota-sienta-search.jpg?itok=sspCMPZ5" alt="2018 Toyota Sienta" class="lazy-loaded">--}}
                                    {{--</a>--}}
                                    {{--<div class="media__body">--}}
                                        {{--<h3 class="new-car__title  zeta  flush"><a href="https://www.carlist.my/new-car/toyota/2018/sienta/40899">2018 Toyota Sienta</a>--}}
                                        {{--</h3>--}}
                                        {{--<div class="rating  rating--stars  rating--small  push-quarter--ends">--}}
                                            {{--<div class="stars">--}}
                                                {{--<i class="icon  icon--star"></i>--}}
                                                {{--<i class="icon  icon--star"></i>--}}
                                                {{--<i class="icon  icon--star"></i>--}}
                                                {{--<i class="icon  icon--star"></i>--}}
                                                {{--<i class="icon  icon--star"></i>--}}
                                            {{--</div>--}}

                                            {{--<div class="stars  stars--rating" style="width:80%">--}}
                                                {{--<i class="icon  icon--star"></i>--}}
                                                {{--<i class="icon  icon--star"></i>--}}
                                                {{--<i class="icon  icon--star"></i>--}}
                                                {{--<i class="icon  icon--star"></i>--}}
                                                {{--<i class="icon  icon--star"></i>--}}
                                            {{--</div>--}}
                                        {{--</div>--}}
                                        {{--<div class="new-car__price  zeta  weight--bold">From RM 90,200</div>--}}
                                    {{--</div>--}}
                                {{--</article>--}}
                                {{--<article class="media  media--listing  box  push-half--top">--}}
                                    {{--<a href="https://www.carlist.my/new-car/toyota/2018/alphard/8203" class="media__img  one-third  push-half--right">--}}
                                        {{--<img src="https://content.icarcdn.com/styles/thumbnail_small/s3/field/car-model/search/2016/toyota-alphard-search.jpeg?itok=pt556MhH" data-src="https://content.icarcdn.com/styles/thumbnail_small/s3/field/car-model/search/2016/toyota-alphard-search.jpeg?itok=pt556MhH" alt="2018 Toyota Alphard" class="lazy-loaded">--}}
                                    {{--</a>--}}
                                    {{--<div class="media__body">--}}
                                        {{--<h3 class="new-car__title  zeta  flush"><a href="https://www.carlist.my/new-car/toyota/2018/alphard/8203">2018 Toyota Alphard</a>--}}
                                        {{--</h3>--}}
                                        {{--<div class="rating  rating--stars  rating--small  push-quarter--ends">--}}
                                            {{--<div class="stars">--}}
                                                {{--<i class="icon  icon--star"></i>--}}
                                                {{--<i class="icon  icon--star"></i>--}}
                                                {{--<i class="icon  icon--star"></i>--}}
                                                {{--<i class="icon  icon--star"></i>--}}
                                                {{--<i class="icon  icon--star"></i>--}}
                                            {{--</div>--}}

                                            {{--<div class="stars  stars--rating" style="width:80%">--}}
                                                {{--<i class="icon  icon--star"></i>--}}
                                                {{--<i class="icon  icon--star"></i>--}}
                                                {{--<i class="icon  icon--star"></i>--}}
                                                {{--<i class="icon  icon--star"></i>--}}
                                                {{--<i class="icon  icon--star"></i>--}}
                                            {{--</div>--}}
                                        {{--</div>--}}
                                        {{--<div class="new-car__price  zeta  weight--bold">From RM 408,400</div>--}}
                                    {{--</div>--}}
                                {{--</article>--}}
                            {{--</div>--}}

                            {{--<div class="push--bottom  js-part-news">--}}
                                {{--<h2 class="headline  epsilon">--}}
                                    {{--Automotive News        </h2>--}}
                                {{--<div class="grid  grid--half  js-grid-match__wraper">--}}
                                    {{--<div class="grid__item  one-half  ">    <article class="article  article--listing  article--listing-sidebar  box  media  push-half--bottom  js-grid--match" style="min-height: 128px; max-height: 128px;">--}}
                                            {{--<a href="https://www.carlist.my/news/cara-pantas-tuntut-insurans-selepas-kemalangan-jika-bukan-salah-anda-84329/84329/" class="block  text--center  push-half--bottom">--}}
                                                {{--<img class="valign--top lazy-loaded" src="https://img5.icarcdn.com/92348/main-s_cara-pantas-tuntut-insurans-selepas-kemalangan-jika-bukan-salah-anda-84329_000000092348_1074a854_5954_419c_b999_ddd0dcbd19be.jpg" alt="Cara Pantas Tuntut Insurans Selepas Kemalangan Jika Bukan Salah Anda" data-src="https://img5.icarcdn.com/92348/main-s_cara-pantas-tuntut-insurans-selepas-kemalangan-jika-bukan-salah-anda-84329_000000092348_1074a854_5954_419c_b999_ddd0dcbd19be.jpg" data-amp-width="283" data-amp-height="200">        </a>--}}
                                            {{--<div class="media__body">--}}
                                                {{--<h3 class="article__title  zeta  push-quarter--bottom">--}}
                                                    {{--<a href="https://www.carlist.my/news/cara-pantas-tuntut-insurans-selepas-kemalangan-jika-bukan-salah-anda-84329/84329/" class="text--clamp">Cara Pantas Tuntut Insurans Selepas Kemalangan Jika Bukan Salah Anda</a>--}}
                                                {{--</h3>--}}
                                                {{--<a href="https://www.carlist.my/news/car-owners-guides/" class="pill  pill--car-owners-guides  nano  soft-quarter--sides  push-quarter--bottom">Car Owners' Guides</a>--}}
                                                {{--<div class="article__meta  text--muted  micro  text--truncate  text--uppercase">--}}
                {{--<span>--}}
                                            {{--<a href="https://www.carlist.my/authors/961/muhammad-sharil-tarmize">Muhammad Sharil Tarmize</a>--}}
                                    {{--</span>--}}
                                                    {{--<span class="block">September 28, 2021</span>--}}
                                                {{--</div>--}}
                                            {{--</div>--}}
                                        {{--</article>--}}
                                    {{--</div>                <div class="grid__item  one-half  ">    <article class="article  article--listing  article--listing-sidebar  box  media  push-half--bottom  js-grid--match" style="min-height: 128px; max-height: 128px;">--}}
                                            {{--<a href="https://www.carlist.my/news/interstate-travel-coming-in-october-first-half-muhyiddin-84322/84322/" class="block  text--center  push-half--bottom">--}}
                                                {{--<img class="valign--top lazy-loaded" src="https://img3.icarcdn.com/22348/main-s_interstate-travel-coming-in-october-first-half-muhyiddin-84322_000000022348_f5ea4eb5_d1a3_4572_afe6_2b771deff158.jpg" alt="Interstate Travel Coming In October First Half, Says Muhyiddin" data-src="https://img3.icarcdn.com/22348/main-s_interstate-travel-coming-in-october-first-half-muhyiddin-84322_000000022348_f5ea4eb5_d1a3_4572_afe6_2b771deff158.jpg" data-amp-width="283" data-amp-height="200">        </a>--}}
                                            {{--<div class="media__body">--}}
                                                {{--<h3 class="article__title  zeta  push-quarter--bottom">--}}
                                                    {{--<a href="https://www.carlist.my/news/interstate-travel-coming-in-october-first-half-muhyiddin-84322/84322/" class="text--clamp">Interstate Travel Coming In October First Half, Says Muhyiddin</a>--}}
                                                {{--</h3>--}}
                                                {{--<a href="https://www.carlist.my/news/auto-news/" class="pill  pill--auto-news  nano  soft-quarter--sides  push-quarter--bottom">Auto News</a>--}}
                                                {{--<div class="article__meta  text--muted  micro  text--truncate  text--uppercase">--}}
                {{--<span>--}}
                                            {{--<a href="https://www.carlist.my/authors/841/jim-kem">Jim Kem </a>--}}
                                    {{--</span>--}}
                                                    {{--<span class="block">September 28, 2021</span>--}}
                                                {{--</div>--}}
                                            {{--</div>--}}
                                        {{--</article>--}}
                                    {{--</div>                <div class="grid__item  one-half  ">    <article class="article  article--listing  article--listing-sidebar  box  media  push-half--bottom  js-grid--match" style="min-height: 128px; max-height: 128px;">--}}
                                            {{--<a href="https://www.carlist.my/news/how-can-a-three-cylinder-engine-produce-600-horsepower-84316/84316/" class="block  text--center  push-half--bottom">--}}
                                                {{--<img class="valign--top" src="//common.icarcdn.com//images/placeholder--news.png" alt="How Can A Three-Cylinder Engine Produce 600 Horsepower?" data-src="https://img2.icarcdn.com/61348/main-s_how-can-a-three-cylinder-engine-produce-600-horsepower-84316_000000061348_e8c5df4f_36ce_42f0_b8f5_717b9acba798.jpg" data-amp-width="283" data-amp-height="200">        </a>--}}
                                            {{--<div class="media__body">--}}
                                                {{--<h3 class="article__title  zeta  push-quarter--bottom">--}}
                                                    {{--<a href="https://www.carlist.my/news/how-can-a-three-cylinder-engine-produce-600-horsepower-84316/84316/" class="text--clamp">How Can A Three-Cylinder Engine Produce 600 Horsepower?</a>--}}
                                                {{--</h3>--}}
                                                {{--<a href="https://www.carlist.my/news/insights/" class="pill  pill--insights  nano  soft-quarter--sides  push-quarter--bottom">Insights</a>--}}
                                                {{--<div class="article__meta  text--muted  micro  text--truncate  text--uppercase">--}}
                {{--<span>--}}
                                            {{--<a href="https://www.carlist.my/authors/884/adam-aubrey">Adam Aubrey </a>--}}
                                    {{--</span>--}}
                                                    {{--<span class="block">September 27, 2021</span>--}}
                                                {{--</div>--}}
                                            {{--</div>--}}
                                        {{--</article>--}}
                                    {{--</div>                <div class="grid__item  one-half  ">    <article class="article  article--listing  article--listing-sidebar  box  media  push-half--bottom  js-grid--match" style="min-height: 128px; max-height: 128px;">--}}
                                            {{--<a href="https://www.carlist.my/news/wee-refusal-of-license-to-senior-citizens-discriminatory-84312/84312/" class="block  text--center  push-half--bottom">--}}
                                                {{--<img class="valign--top" src="//common.icarcdn.com//images/placeholder--news.png" alt="Wee: Refusal Of License To Senior Citizens Discriminatory" data-src="https://img3.icarcdn.com/21348/main-s_wee-refusal-of-license-to-senior-citizens-discriminatory-84312_000000021348_ced9836f_58df_4505_9ef8_0b7b98f3defd.jpg" data-amp-width="283" data-amp-height="200">        </a>--}}
                                            {{--<div class="media__body">--}}
                                                {{--<h3 class="article__title  zeta  push-quarter--bottom">--}}
                                                    {{--<a href="https://www.carlist.my/news/wee-refusal-of-license-to-senior-citizens-discriminatory-84312/84312/" class="text--clamp">Wee: Refusal Of License To Senior Citizens Discriminatory</a>--}}
                                                {{--</h3>--}}
                                                {{--<a href="https://www.carlist.my/news/auto-news/" class="pill  pill--auto-news  nano  soft-quarter--sides  push-quarter--bottom">Auto News</a>--}}
                                                {{--<div class="article__meta  text--muted  micro  text--truncate  text--uppercase">--}}
                {{--<span>--}}
                                            {{--<a href="https://www.carlist.my/authors/884/adam-aubrey">Adam Aubrey </a>--}}
                                    {{--</span>--}}
                                                    {{--<span class="block">September 27, 2021</span>--}}
                                                {{--</div>--}}
                                            {{--</div>--}}
                                        {{--</article>--}}
                                    {{--</div>        </div>--}}
                            {{--</div>--}}
                            {{--<!-- listings_portrait -->--}}
                            {{--<div class="ad_unit--side  push--bottom  text--center  sticky-ad-pushed  js-sticky-ads-desktop" id="div-gpt-ad-1455074210869-0">--}}
                            {{--</div>--}}
                        {{--</aside>--}}
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal  modal--default  modal--error  js-modal-error  visuallyhidden">
        <div class="modal__head  flexbox">
            <div class="flexbox__item  modal__title">Response unavailable</div>
            <div class="flexbox__item  modal__destroy   b-close  weight--light">×</div>
        </div>
        <div class="modal__body  soft  text--center">
            <div>We are unable to process your request at the moment. Please check your connection and try again.</div>
            <button class="btn  btn--primary  push-half--top  b-close">Close</button>
        </div>
    </div><div class="modal  modal--default  modal--error-saved-cars  js-modal-error-saved-cars  visuallyhidden">
        <div class="modal__head  flexbox">
            <div class="flexbox__item  modal__title">Saved Ads Limit Reached</div>
            <div class="flexbox__item  modal__destroy   b-close  weight--light">×</div>
        </div>
        <div class="modal__body  soft">
            <div class="js-modal-error-message">
                <p>You can save up to 50 ads only.</p>
                <div>To save this car, remove some of your saved ads.</div>
            </div>
        </div>
        <div class="modal__foot  soft--sides  soft-half--ends  text--right">
            <a class="btn  btn--primary  push-half--top" href="https://dealer.carlist.my/pages/buyerAction/ManageSavedCar.aspx?is_private=true&amp;return_url=https%3A%2F%2Fwww.carlist.my%2Fcars-for-sale%2Ftoyota%2F86%2Fmalaysia">Manage Saved Ads</a>
        </div>
    </div>
    <div class="modal  js-modal-dealer  visuallyhidden  modal--dealer  modal--dealer-ctr">
        <div class="modal__head  flexbox">
            <div class="flexbox__item  modal__title">Contact Seller</div>
            <div class="flexbox__item  modal__destroy   b-close  weight--light  js-modal-destroy">×</div>
        </div>

        <div class="modal__body  hard  fill--grey">
            <div class="contact--option  contact--phones  fill--white  visuallyhidden  u-hide  js-dealer-phone">
                <div class="contact--option  contact--phones  fill--grey  js-contact--phones">
                    <div class="dealer  fill--white  js-dealer-name">
                        <div class="flexbox">
                            <div class="flexbox__row">
                                <div class="flexbox__item  valign--top  visuallyhidden">
                                    <span class="dealer__badges  icon  icon--thumb-up  text--center"></span>
                                </div>
                                <div class="flexbox__item  valign--top  one-whole">
                                    <div class="dealer__name">
                                        <span class="listing__seller-name  js-chat-profile-fullname  c-seller-name  u-text-5  u-margin-bottom-none"></span>
                                    </div>

                                    <div class="dealer__location  milli">
                    <span class="listing__location  c-seller-location  c-breadcrumb  u-margin-bottom-none  u-margin-top-xs  u-text-7">
                        <span class="js-seller-profile-location"></span> » <span class="js-seller-profile-area"></span>
                    </span>
                                    </div>
                                </div>

                                <div class="flexbox__item  valign--top  soft--left  space--nowrap">
                                    <div class="dealer__type  text--center    is--verified  js-dealer__type    @in--nitro  u-flex  u-flex--items-center">
                                        <div class="dealer__badge  flyout ">
                                            <span class="icon  icon--thumb-up       @in--nitro  icon--20   icon--product-verified"></span>
                                            <span class="flyout__content  flyout__content--tip  u-hide">This 'Trusted Dealer' has a proven track record of upholding the best car selling practices certified by Carlist.my</span>
                                        </div>
                                        <span class="listing__seller-type   js-seller-profile-type"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Chat show block removed here as requested for MY -->
                    <div class="contact__group  push-quarter--top  fill--white">
                    </div>
                </div>
            </div>
            <!-- ID and MY -->

            <div class="contact--option  fill--grey  visuallyhidden  u-hide  js-dealer-line-check">
                <div class="dealer  fill--white  js-dealer-name">
                    <div class="flexbox">
                        <div class="flexbox__row">
                            <div class="flexbox__item  valign--top  visuallyhidden">
                                <span class="dealer__badges  icon  icon--thumb-up  text--center"></span>
                            </div>
                            <div class="flexbox__item  valign--top  one-whole">
                                <div class="dealer__name">
                                    <span class="listing__seller-name  js-chat-profile-fullname  c-seller-name  u-text-5  u-margin-bottom-none"></span>
                                </div>

                                <div class="dealer__location  milli">
                    <span class="listing__location  c-seller-location  c-breadcrumb  u-margin-bottom-none  u-margin-top-xs  u-text-7">
                        <span class="js-seller-profile-location"></span> » <span class="js-seller-profile-area"></span>
                    </span>
                                </div>
                            </div>

                            <div class="flexbox__item  valign--top  soft--left  space--nowrap">
                                <div class="dealer__type  text--center    is--verified  js-dealer__type    @in--nitro  u-flex  u-flex--items-center">
                                    <div class="dealer__badge  flyout ">
                                        <span class="icon  icon--thumb-up       @in--nitro  icon--20   icon--product-verified"></span>
                                        <span class="flyout__content  flyout__content--tip  u-hide">This 'Trusted Dealer' has a proven track record of upholding the best car selling practices certified by Carlist.my</span>
                                    </div>
                                    <span class="listing__seller-type   js-seller-profile-type"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="contact--option  contact--line  fill--grey  visuallyhidden  u-hide  js-dealer-line-number">
                <div class="dealer  fill--white  js-dealer-name">
                    <div class="flexbox">
                        <div class="flexbox__row">
                            <div class="flexbox__item  valign--top  visuallyhidden">
                                <span class="dealer__badges  icon  icon--thumb-up  text--center"></span>
                            </div>
                            <div class="flexbox__item  valign--top  one-whole">
                                <div class="dealer__name">
                                    <span class="listing__seller-name  js-chat-profile-fullname  c-seller-name  u-text-5  u-margin-bottom-none"></span>
                                </div>

                                <div class="dealer__location  milli">
                    <span class="listing__location  c-seller-location  c-breadcrumb  u-margin-bottom-none  u-margin-top-xs  u-text-7">
                        <span class="js-seller-profile-location"></span> » <span class="js-seller-profile-area"></span>
                    </span>
                                </div>
                            </div>

                            <div class="flexbox__item  valign--top  soft--left  space--nowrap">
                                <div class="dealer__type  text--center    is--verified  js-dealer__type    @in--nitro  u-flex  u-flex--items-center">
                                    <div class="dealer__badge  flyout ">
                                        <span class="icon  icon--thumb-up       @in--nitro  icon--20   icon--product-verified"></span>
                                        <span class="flyout__content  flyout__content--tip  u-hide">This 'Trusted Dealer' has a proven track record of upholding the best car selling practices certified by Carlist.my</span>
                                    </div>
                                    <span class="listing__seller-type   js-seller-profile-type"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="contact__group  push-quarter--top  fill--white"></div>
            </div>
            <div class="contact--option  fill--white  visuallyhidden  u-hide  js-ncf-option-send-message-flow">
                <div class="dealer  fill--white  js-dealer-name">
                    <div class="flexbox">
                        <div class="flexbox__row">
                            <div class="flexbox__item  valign--top  visuallyhidden">
                                <span class="dealer__badges  icon  icon--thumb-up  text--center"></span>
                            </div>
                            <div class="flexbox__item  valign--top  one-whole">
                                <div class="dealer__name">
                                    <span class="listing__seller-name  js-chat-profile-fullname  c-seller-name  u-text-5  u-margin-bottom-none"></span>
                                </div>

                                <div class="dealer__location  milli">
                    <span class="listing__location  c-seller-location  c-breadcrumb  u-margin-bottom-none  u-margin-top-xs  u-text-7">
                        <span class="js-seller-profile-location"></span> » <span class="js-seller-profile-area"></span>
                    </span>
                                </div>
                            </div>

                            <div class="flexbox__item  valign--top  soft--left  space--nowrap">
                                <div class="dealer__type  text--center    is--verified  js-dealer__type    @in--nitro  u-flex  u-flex--items-center">
                                    <div class="dealer__badge  flyout ">
                                        <span class="icon  icon--thumb-up       @in--nitro  icon--20   icon--product-verified"></span>
                                        <span class="flyout__content  flyout__content--tip  u-hide">This 'Trusted Dealer' has a proven track record of upholding the best car selling practices certified by Carlist.my</span>
                                    </div>
                                    <span class="listing__seller-type   js-seller-profile-type"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <form action="/ajax/profileupdatewithlead" class="contact  contact--form  fill--white  js-update-profile  js-form-ajax  js-form-validation" method="POST" data-success-callback="profileUpdateSuccess" data-failure-callback="profileUpdateFailure">

                    <div class="js-additional-message  js-additional-message-view">

                        <div class="alert  alert--error  milli  visuallyhidden  js-form-error  js-option-form-error  js-form-error-common">
                            Invalid form data submitted! Failed to process request.    </div>

                        <div class="form-group">
                            <div><span class="weight--semibold">Please send me more information about the car</span>
                                <span class="">*</span></div>
                            <div class="push-half--top">
                                <div class="soft-quarter--ends">
                                    <label class="checkbox  js-more-info-option">
                                        <input type="checkbox" name="info__options[]" class="visuallyhidden  js-question-checkbox" value="Is this car still available?">
                                        <span class="icon  icon--md-done"></span>
                                        Is this car still available?                </label>
                                </div>

                                <div class="soft-quarter--ends">
                                    <label class="checkbox  js-more-info-option">
                                        <input type="checkbox" name="info__options[]" class="visuallyhidden  js-question-checkbox" value="I would like to view this car.">
                                        <span class="icon  icon--md-done"></span>
                                        I would like to view this car.                </label>
                                </div>

                                <div class="soft-quarter--ends">
                                    <label class="checkbox  js-more-info-option">
                                        <input type="checkbox" name="info__options[]" class="visuallyhidden  js-question-checkbox" value="Is a full loan available?">
                                        <span class="icon  icon--md-done"></span>
                                        Is a full loan available?                </label>
                                </div>

                                <div class="soft-quarter--ends">
                                    <label class="checkbox  js-more-info-option">
                                        <input type="checkbox" name="info__options[]" class="visuallyhidden  js-question-checkbox" value="What is your best price?">
                                        <span class="icon  icon--md-done"></span>
                                        What is your best price?                </label>
                                </div>

                                <div class="soft-quarter--ends">
                                    <label class="checkbox  js-more-info-option">
                                        <input type="checkbox" name="info__options[]" class="visuallyhidden  js-question-checkbox" value="Where is your location?">
                                        <span class="icon  icon--md-done"></span>
                                        Where is your location?                </label>
                                </div>

                                <div class="soft-quarter--top">
                                    <div class="form-group  flush--bottom">
                                        <label for="additional-message" class="visuallyhidden">
                                            Additional message to seller                    </label>

                                        <div class="milli  weight--normal   required-field  visuallyhidden  js-form-error  js-error-remarks" role="alert"></div>

                                        <div class="input-group">
                                            <textarea id="additional-message" name="additonal_message" class="input  one-whole  js-form-element-additional-message" data-pattern="^.{1,500}$" placeholder="Additional message to seller" data-error="You have exceeded maximum character limit (max 500 characters)"></textarea>
                                            <span class="icon  icon--message  muted  append--before"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="alert  alert--default  push-half--top  text--center  full--width  js-user-signin">
                            <a href="#" class="js-contact-action" data-auth="ctr" data-contact-action="login">Sign in</a> or <a href="#" class="js-contact-action" data-contact-action="signup" data-auth="signup">Register</a> is required to send a message    </div>

                        <div class="form-group  push-half--top  js-terms">
                            <label for="terms" class="checkbox  milli">
                                <input id="terms" name="terms" type="checkbox" value="1" class="visuallyhidden  js-disable-form-submit  js-form-element-required" checked="checked" data-error="Please acknowledge the terms and conditions.">

                                <span class="icon  icon--md-done"></span>

                                Your continued use of this site constitutes your acceptance of the <a href="https://www.carlist.my/terms-and-conditions-of-use">Terms and Conditions of Use</a> and the <a href="https://www.carlist.my/personal-data-protection-notice">Personal Data Protection Notice</a>        </label>

                            <div class="alert  alert--error  visuallyhidden  js-form-error  js-error-terms" role="alert"></div>
                        </div>

                        <button class="btn  btn--large  btn--primary  btn--full  push-quarter--top  js-btn-additional-info" type="button"><span class="listing__message">Send Message</span>
                        </button>
                    </div>

                    <div class="visuallyhidden  js-update-profile-view">

                        <div class="alert  alert--error  milli  visuallyhidden  js-form-error  js-form-error-common">
                            Invalid form data submitted! Failed to process request.        </div>

                        <div class="alert  alert--success  milli  visuallyhidden  js-form-error  js-form-success">
                            Your enquiry has been submitted. Thank you.        </div>

                        <div class="form-group">
                            <div class="flexbox  push--bottom">
                                <div class="flexbox__item  tight"><img class="icon  icon--protect" src="http://localhost/911/public/uploads/all/L5ZHiNQuxthcta7lZmZs62xBrwG3UpK8eToN8FMr.png" alt=""></div>
                                <h5 class="flexbox__item  headline  delta  soft-half--left  one-whole">Carlist.my security</h5>
                            </div>
                            <div class="soft-half--bottom">This helps protect our marketplace and guarantees a safe environment for both buyers and sellers.</div>
                            <div>
                                <div class="soft-quarter--ends js-update-profile-name-block">
                                    <div class="weight--normal  milli  required-field  js-form-error  js-error-full_name  visuallyhidden" role="alert"></div>
                                    <label><span class="milli  weight--normal">Name</span>
                                        <span class="required-field  weight--light">*</span>
                                    </label>
                                    <input class="input  one-whole  js-form-element-required" id="update-profile-name" name="full_name" maxlength="64" type="text" data-pattern="^[a-zA-Z]{1}[a-zA-Z\s\.-]{1,63}$" data-error="Please enter a valid name">
                                </div>

                                <div class="soft-quarter--ends  visuallyhidden  js-update-profile-email">
                                    <div class="weight--normal  milli  required-field  js-form-error  js-error-email  visuallyhidden" role="alert"></div>
                                    <label><span class="milli  weight--normal">Email Address</span>
                                        <span class="required-field weight--light">*</span>
                                    </label>
                                    <input class="input  one-whole" id="update-profile-email" name="email" maxlength="64" type="email" data-error="Please enter a valid Email address.">
                                </div>

                                <div class="soft-quarter--ends js-update-profile-phone-block">
                                    <div class="weight--normal  milli  required-field  js-form-error  js-error-phone  visuallyhidden" role="alert"></div>
                                    <label><span class="weight--normal  milli">Mobile Number</span>
                                        <span class="required-field  weight--light">*</span>
                                    </label>
                                    <input class="input  one-whole  js-form-element-required" id="update-profile-phone" name="phone" placeholder="e.g. 0123456789" type="text" data-pattern="^\+?[0-9]{10,12}$" data-error="Please enter a valid Phone Number">
                                </div>
                                <div class="text--muted  milli">Your personal details won't be shared with a third party</div>

                            </div>
                        </div>

                        <input type="hidden" name="_csrf" value="fv7i7kancOBX4OoEAALN8DYHm65KapOQJZsPZijuL8wWzoaxd9Ue2SWwuHE5ap-hZUHtlj0Q6scd4WkhX4lmnA==">
                        <input type="hidden" name="profileId" value="">
                        <input type="hidden" name="sellerId" value="">
                        <input type="hidden" name="listingId" value="">
                        <input type="hidden" name="location" value="">
                        <input type="hidden" name="userId" value="">


                        <button class="btn  btn--large  btn--full  btn--primary  weight--semibold  push-half--top button__update" type="submit" value="Submit" data-enabled-text="<span class='listing__message'>Continue to Message</span>" data-disabled-text="<span class='listing__message'>Sending...</span>">
                            <span class="listing__message">Continue to Message</span>
                        </button>
                    </div>

                </form>

                <div class="contact__fill-height  fill--white  full--height  visuallyhidden  u-hide  js_profile_update_message-sent">
                    <!--Start: Template-->
                    <div class="soft  u-align-center  u-padding-ends-xxl">
                        <div class="text--center  soft-half--top  push--ends  one-whole">
                            <div class="push"><span class="icon  icon-check-circle  icon--md-done icon--check  icon--64  icon--positive  u-margin-sides-auto  u-margin-bottom-xs"></span>
                            </div>
                        </div>
                        <div class="delta  weight--semibold  text--center  text--success  u-text-4  u-text-bold  u-margin-bottom-xs">Message Sent</div>
                        <div class="soft-half  text--center">Your message has been sent.</div>
                    </div>
                    <!--End: Template  -->
                </div>
            </div>
            <div class="js-is-profile-complete  visuallyhidden" data-user_id="" data-is_profile_complete="" data-profile_name="" data-profile_phone="" data-profile_email=""></div>
        </div>


        <div class="fill--white">
            <div class="private-essential-services">
                <a href="https://www.carlist.my/form/carlist360" target="_blank" class="block essential-services">
                    <picture>
                        <img data-src="https://carlist.icarcdn.com/images/carlist360/carlist-360-mobile.webp" alt="Carlist.my 360" class="one-whole dealer lozad" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7">

                        <source type="image/webp" src="https://carlist.icarcdn.com/images/carlist360/carlist-360-mobile.webp" alt="Carlist.my 360" class="one-whole dealer">

                        <source type="image/jpeg" src="https://carlist.icarcdn.com/images/carlist360/carlist-360-mobile.jpg" alt="Carlist.my 360" class="one-whole dealer">
                    </picture>
                </a>
            </div>
        </div>

    </div>
    <div class="basket  fixed  transition--default  palm-one-whole  js-compare-basket  visuallyhidden" data-compare-type="car" data-compare-basket-count="0">
        <div class="basket__toggler  soft-half  js-toggler  cf  js-unveil" data-target="#compare_listings">
            <div class="basket__title  float--left">
                <i class="icon  icon--compare-car  icon--flexible  push-quarter--right"></i>Comparison        </div>
            <span class="basket__count  milli  fill--white  float--right  weight--bold  text--center  js-compare-basket-count">0</span>
        </div>

        <div id="compare_listings" class="basket__listings  fill--white  soft-half  js-compare-listings  visuallyhidden">
            <div class="visuallyhidden  alert  alert--warning  milli  flush--top  push-half--bottom  js-compare-notification" data-notification-message="You can compare maximum {limit} cars at a time."></div>

            <div class="basket__listings-container  js-compare-basket__listings-container  push--bottom">
            </div>
            <a class="btn  btn--primary  one-whole" href="https://www.carlist.my/car/compare">
                <div class="flexbox">
                    <div class="flexbox__item  one-whole  text--center">
                        Compare cars                </div>
                    <div class="flexbox__item  tight  valign--middle">
                        <span class="basket__count  milli  fill--white  js-compare-basket-count  float--right  weight--bold  flush">0</span>
                    </div>
                </div>
            </a>
        </div>
    </div>
</main>

<div class="modal  modal--default  modal--auth  modal--fixed-foot  visuallyhidden">
    <div class="modal__container">
        <div class="modal__head  flexbox">
            <div class="flexbox__item  modal__title"></div>
            <div class="flexbox__item  modal__destroy  weight--light  b-close">&times;</div>
        </div>

        <div class="modal__body  fill--grey  hard  auth-window  height--auto">
            <div class="loading-screen  absolute  visuallyhidden  js-auth-loading"></div>
            <div class="icarsuite_login  flex  flex--justify-center  soft--ends  visuallyhidden  u-hide"
                 style="background:url('//common.icarcdn.com/images/bg_icarsuite.png') no-repeat bottom right; background-size:246px;">
                <div class="text--center  flex__self-center  push--bottom">
                    <div class="soft-quarter--ends">You are a dealer.</div>
                    <div class="">Please login as a dealer from</div>
                    <div class="text--center  push-half--top  push--bottom">
                        <img src="//common.icarcdn.com/images/logo_icarsuite_default_full.svg"
                             alt="iCar Suite" width="153" height="23" class=""/>
                    </div>
                    <a href="https://accounts.icarsuite.com/?lang=my" class="btn  btn--primary  push-half--top  soft--sides"
                       target="_blank">Sign in</a>
                </div>
            </div>
            <form action="/ajax/login"
                  class="chat-form  auth-form  fill--white  visuallyhidden  js-chat-login  js-login  js-form-ajax  js-form-validation"
                  method="POST" data-success-callback="authSuccess" data-failure-callback="authFailure"
                  data-loader-callback="authLoader">
                <div class="chat-form__head  flexbox">
                    <div class="flexbox__item  one-whole">Sign In</div>
                    <div class="flexbox__item js-chat-close" title="Close">
                        <span class="icon  icon--close  icon--md-close"></span>
                    </div>
                </div>

                <div class="auth-social  soft">
                    <a class="btn  btn--full  btn--facebook  js-login-fb  push-half--bottom">
                        <img class="btn__image  valign--top" width="20" height="20"
                             src="//common.icarcdn.com/images/logo-facebook.png" alt="logo-facebook">
                        Continue with Facebook        </a>

                    <a class="btn  btn--full  btn--google" id="login-gplus">
                        <img class="btn__image  valign--top" width="20" height="20"
                             src="//common.icarcdn.com/images/logo-google.png" alt="logo-google">
                        Continue with Google        </a>
                </div>

                <hr class="rule  flush--bottom">

                <div
                        class="visuallyhidden  alert  alert--error  milli  flush--top  js-form-error  js-form-error-common  text--center">
                    Unable to login, please try again.    </div>

                <div class="chat-welcome  visuallyhidden">Fill up the fields below to login</div>

                <div class="chat-form__body soft">
                    <div class="form-group">
                        <div class="required-field  js-form-error  js-error-user_name  visuallyhidden" role="alert"></div>
                        <label for="user_name_login">Email address / User Name <span
                                    class="required-field">*</span></label>
                        <input id="user_name_login" name="user_name" type="text" class="input  one-whole  js-form-element-required"
                               data-error="Please enter a valid email address / user name"
                               tabindex="1" value=""/>
                    </div>

                    <div class="form-group">
                        <div class="required-field  js-form-error  js-error-password  visuallyhidden" role="alert"></div>
                        <label for="password_login">Password <span class="required-field">*</span></label>
                        <input id="password_login" name="password" type="password"
                               class="input  one-whole  js-form-element-required"
                               data-error="Please enter a valid password" tabindex="2"/>
                    </div>

                    <div class="flexbox  soft-half--bottom  milli">
                        <div class="flexbox__item">
                            <label class="checkbox" for="remember_me">
                                <input name="remember_me" id="remember_me" type="checkbox" class="visuallyhidden" checked="">
                                <span class="icon  icon--md-done"></span>
                                Remember Me                </label>
                        </div>
                        <div class="flexbox__item text--right">
                            <a href="https://www.carlist.my/forgotpassword">Forgot Password</a>
                        </div>
                    </div>

                    <div class="soft-half--bottom  milli">
                    </div>

                    <input type="hidden" name="isSponsorPage" value="false"/>

                    <div class="form-action">
                        <input type="hidden" name="_csrf"
                               value="fv7i7kancOBX4OoEAALN8DYHm65KapOQJZsPZijuL8wWzoaxd9Ue2SWwuHE5ap-hZUHtlj0Q6scd4WkhX4lmnA=="/>
                        <button class="btn  btn--primary  one-whole">Sign In</button>
                    </div>
                    <!-- link register -->
                    <div class="text--center  push-half--top">
                        <a href="#"
                           class="chat-form__pointer  one-whole  text--center  milli  js-show-signup  js-form-pointer  push-top">
                            <span class="text--muted">Don't have an account?</span>
                            Register now            </a>
                    </div>
                </div>

                <div class="auth-switch  modal__foot  fill--grey  text--center">
                    <a href="https://accounts.icarsuite.com/signin?lang=en&project=carlist" class="milli   flex  flex--justify-center  flex--items-center"
                       target="_blank">
                        <img src="//common.icarcdn.com/images/logo_icarsuite_default.svg" height="20" width="20"
                             class="push-half--right">
                        <div>Sign in as Dealer / Agent</div>        </a>

                </div>
            </form>

            <!-- start: .chat-body -->
            <!-- start: .chat-body -->
            <form action="/ajax/signup"
                  class="chat-form  auth-form  fill--white  js-chat-signup   visuallyhidden  js-signup  js-form-ajax  js-form-validation"
                  method="POST" data-success-callback="authSuccess" data-failure-callback="authFailure"
                  data-loader-callback="authLoader">
                <div class="chat-form__head  flexbox">
                    <div class="flexbox__item  one-whole">Register</div>
                    <div class="flexbox__item  js-chat-close" title="Close">
                        <span class="icon  icon--close  icon--md-close"></span>
                    </div>
                </div>

                <div
                        class="visuallyhidden  alert  alert--error  milli  flush--top  js-form-error  js-form-error-common  text--center">
                    Unable to signup, please try again.    </div>
                <div class="auth-social text--center soft--top soft--half">
        <span>
            Register with <a class="js-login-fb">Facebook</a> <span class="login-or">OR</span> <a id="login-gplus-signup">Google</a>        </span>
                </div>

                <div class="flexbox  push--top  push-half--bottom">
                    <div class="flexbox__item  one-half">
                        <hr class="rule  flush">
                    </div>
                    <div class="flexbox__item  muted  soft-quarter--sides">
                        OR        </div>
                    <div class="flexbox__item  one-half">
                        <hr class="rule  flush">
                    </div>
                </div>

                <div class="chat-form__body  soft">
                    <!--Will update the display logic later-->
                    <div class="chat-welcome  visuallyhidden">Fill up the fields below to register</div>

                    <div class="form-group">
                        <div class="required-field  js-form-error  js-error-full_name  visuallyhidden" role="alert"></div>

                        <label for="full_name_signup">Your Name <span
                                    class="required-field">*</span></label>

                        <input id="full_name_signup" name="full_name" type="text" class="input  one-whole  js-form-element-required"
                               data-error="Please enter a valid name"
                               data-pattern="^[a-zA-Z]{1}[a-zA-Z\s\.-]{6,100}$"
                               tabindex="3">
                    </div>

                    <div class="form-group">
                        <div class="required-field  js-form-error  js-error-user_name  visuallyhidden" role="alert"></div>

                        <label for="user_name_signup">Email address <span
                                    class="required-field">*</span></label>

                        <input id="user_name_signup" name="user_name" type="text" class="input  one-whole  js-form-element-required"
                               data-error="Please enter a valid email address"
                               data-pattern='^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$'
                               tabindex="4"/>
                    </div>

                    <div class="form-group">
                        <div class="required-field  js-form-error  js-error-phone_number  visuallyhidden" role="alert"></div>

                        <label for="phone_number">Mobile Number <span
                                    class="required-field">*</span></label>

                        <input id="phone_number" name="phone_number" type="text" value=""
                               class="input  one-whole  js-form-element-required"
                               placeholder="e.g. 0123456789"
                               data-pattern="^\+?[0-9]{8,12}$"
                               data-error="Please enter a valid mobile number"
                               tabindex="5"
                        />
                    </div>

                    <div class="form-group">
                        <div class="required-field  js-form-error  js-error-password  visuallyhidden" role="alert"></div>

                        <label for="password_signup">Password <span class="required-field">*</span></label>

                        <input id="password_signup" name="password" type="password"
                               class="input  one-whole  js-form-element-required"
                               data-error="Please enter a valid password and must be between 6 to 30 characters"
                               data-pattern="^.{6,30}$"
                               tabindex="6"
                               value=""/>
                    </div>

                    <div class="soft-half--bottom  milli">

                        By registering, you accept our <a target="_blank" href="https://www.carlist.my/terms-and-conditions-of-use">Terms Of Use</a> & <a target="_blank" href="https://www.carlist.my/privacy">Privacy Policy</a>, and agree to receive the latest news and direct marketing from us.        </div>

                    <div class="form-actions">
                        <input type="hidden" name="_csrf"
                               value="fv7i7kancOBX4OoEAALN8DYHm65KapOQJZsPZijuL8wWzoaxd9Ue2SWwuHE5ap-hZUHtlj0Q6scd4WkhX4lmnA=="/>
                        <button class="btn  btn--primary  one-whole">Register</button>
                    </div>
                    <div class="text--center soft-half--top  milli  soft-half--bottom">
                        <a href="#" class="js-show-login    js-form-pointer">
                <span class="text--muted">
                    Already have an account?                </span>
                            Sign In            </a>
                    </div>
                </div>

                <div class="auth-switch  modal__foot  fill--grey text--center">
                    <a href="https://accounts.icarsuite.com/register?project=carlist&lang=en"
                       class="milli  flex  flex--justify-center  flex--items-center" target="_blank">
                        <img src="//common.icarcdn.com/images/logo_icarsuite_default.svg" height="20" width="20"
                             class="push-half--right">
                        <div>
                            Register as Dealer / Agent</div>        </a>
                </div>
            </form>
            <!-- start: .chat-body -->
            <!-- start: .profile-update-modal__form -->
            <form action="/ajax/profileupdate"
                  class="profile-update-modal__form  js-profile-update-modal__form  contact--form js-form-validation  is--active visuallyhidden  js-form-ajax"
                  method="post" data-success-callback="chatProfileUpdateSuccess" data-failure-callback="chatProfileUpdateFailure">

                <div class="chat-form__body">
                    <div class="chat-profile__container  top--left  absolute  full">
                        <div class="chat-profile  fill--white  absolute  bottom--left  soft  push-half  palm-one-whole  palm-flush">
                            <div class="flexbox  push--bottom">
                                <div class="flexbox__item  tight"><img class="icon  icon--protect"
                                                                       src="//common.icarcdn.com/images/icon-protect.png"
                                                                       alt=""/></div>
                                <h4 class="flexbox__item  headline  delta  soft-half--left  one-whole">Carlist.my security</h4>
                            </div>
                            <h5 class="headline  epsilon  push-quarter--bottom">Please complete your details below</h5>
                            <div
                                    class="push--bottom">This helps protect our marketplace and guarantees a safe environment for both buyers and sellers.</div>
                            <div
                                    class="alert  alert--error  milli  flush--top  text--center  visuallyhidden  js-form-error  js-form-error-common">
                                Unable to signup, please try again.                </div>

                            <div class="alert  alert--error  milli  visuallyhidden  js-message__missing__fields  ">
                                Please update the missing fields                </div>
                            <div class="alert  alert--error  milli  visuallyhidden  js-validation-error__invalid-phone">
                                Invalid Phone Number                </div>
                            <div class="form-group js-chat-update-profile-name-block">
                                <div class="required-field  visuallyhidden  js-form-error  js-error-full_name" role="alert"></div>

                                <label for="full_name">Name <span class="required-field">*</span></label>

                                <input id="full_name" name="full_name" type="text"
                                       class="input  one-whole  js-form-element-required"
                                       data-pattern="^[a-zA-Z]{1}[a-zA-Z\s\.-]{1,63}$"
                                       data-error="Please enter a valid name"
                                       placeholder=""
                                       tabindex="3">
                            </div>

                            <div class="form-group js-chat-update-profile-email-block">
                                <div class="required-field  visuallyhidden  js-form-error  js-error-email" role="alert"></div>

                                <label for="chat_profile_update_email">Email Address <span
                                            class="required-field">*</span></label>

                                <input id="chat_profile_update_email" name="email" type="text"
                                       class="input  one-whole  js-form-element-required"
                                       data-error="Please enter a valid email address" tabindex="4">
                            </div>

                            <div class="form-group js-chat-update-profile-phone-block">
                                <div class="required-field   visuallyhidden  js-form-error  js-error-phone" role="alert"></div>

                                <label for="phone_number_signup">Mobile Number <span class="required-field">*</span></label>

                                <input name="phone" type="text" value="" id="phone_number_signup"
                                       class="input  one-whole  js-form-element-required"
                                       placeholder="e.g. 0123456789"
                                       data-pattern="^\+?[0-9]{10,12}$"
                                       data-error="Please enter a valid number"
                                       tabindex="5"
                                />
                            </div>
                            <div
                                    class="text--muted">Your personal details won&apos;t be shared with a third party</div>

                            <input type="hidden" id="user_id" value="" name="userId"/>

                            <div class="form-actions  push--top">
                                <input type="hidden" name="_csrf"
                                       value="fv7i7kancOBX4OoEAALN8DYHm65KapOQJZsPZijuL8wWzoaxd9Ue2SWwuHE5ap-hZUHtlj0Q6scd4WkhX4lmnA=="/>
                                <button
                                        class="btn  btn--primary  one-whole  button__update">Update profile</button>
                            </div>
                        </div>
                    </div>
                </div>

            </form>

            <!-- end: .profile-update-modal__form -->
        </div>
    </div>
</div>

{{--<script src="{{ static_asset('assets/js/87daaa6c88.js') }}"></script>--}}
{{--<script src="{{ static_asset('assets/js/4cddf3b261.js') }}"></script>--}}
{{--<script src="{{ static_asset('assets/js/7d9d2d5457.js') }}"></script>--}}
{{--<script src="https://carlist.icarcdn.com/js/auth.7d9d2d5457.js" defer="defer"></script>--}}
{{--<script src="{{ static_asset('assets/js/5d3fb55521.js') }}"></script>--}}
{{--<script src="{{ static_asset('assets/js/44bf569962.js') }}"></script>--}}
{{--<script src="https://carlist.icarcdn.com/js/main.44bf569962.js" defer="defer"></script>--}}
{{--<script src="https://common.icarcdn.com/js/core.87daaa6c88.js" defer="defer"></script>--}}
{{--<script src="https://common.icarcdn.com/js/common.4cddf3b261.js" defer="defer"></script>--}}
{{--<!--<script src="https://carlist.icarcdn.com/js/auth.7d9d2d5457.js" defer="defer"></script>-->--}}
{{--<script src="https://carlist.icarcdn.com/js/listings.5d3fb55521.js" defer="defer"></script>--}}
{{--<!--<script src="https://carlist.icarcdn.com/js/main.44bf569962.js" defer="defer"></script>-->--}}
{{--<script>--}}
    {{--window.dataLayer=window.dataLayer||[];gaPush({'event':'ecommerce_impressions','ecommerce':{impressions:[{"name":"2017 Toyota 86 2.0 GT Coupe","id":8113640,"category":"Recon","price":"RM 168,000","brand":"Toyota 86","variant":"GT","year":2017,"list":"www.carlist.my//cars-for-sale/toyota/86/malaysia","position":0},{"name":"2015 Toyota 86 2.0 Coupe","id":8022075,"category":"Used","price":"RM 135,800","brand":"Toyota 86","variant":"","year":2015,"list":"www.carlist.my//cars-for-sale/toyota/86/malaysia","position":1},{"name":"2017 Toyota 86 2.0 Coupe","id":8098552,"category":"Recon","price":"RM 158,800","brand":"Toyota 86","variant":"","year":2017,"list":"www.carlist.my//cars-for-sale/toyota/86/malaysia","position":2},{"name":"2016 Toyota 86 2.0 Coupe","id":7984218,"category":"Recon","price":"RM 158,000","brand":"Toyota 86","variant":"","year":2016,"list":"www.carlist.my//cars-for-sale/toyota/86/malaysia","position":3},{"name":"2017 Toyota 86 2.0 Coupe","id":8157164,"category":"Recon","price":"RM 168,000","brand":"Toyota 86","variant":"","year":2017,"list":"www.carlist.my//cars-for-sale/toyota/86/malaysia","position":4},{"name":"2016 Toyota 86 2.0 Coupe","id":7856797,"category":"Recon","price":"RM 172,888","brand":"Toyota 86","variant":"","year":2016,"list":"www.carlist.my//cars-for-sale/toyota/86/malaysia","position":5},{"name":"2016 Toyota 86 2.0 Coupe","id":7724612,"category":"Recon","price":"RM 172,000","brand":"Toyota 86","variant":"","year":2016,"list":"www.carlist.my//cars-for-sale/toyota/86/malaysia","position":6},{"name":"2018 Toyota 86 2.0 GT Coupe","id":8074957,"category":"Recon","price":"RM 228,000","brand":"Toyota 86","variant":"GT","year":2018,"list":"www.carlist.my//cars-for-sale/toyota/86/malaysia","position":7},{"name":"2016 Toyota 86 2.0 GT Coupe","id":8187861,"category":"Recon","price":"RM 163,000","brand":"Toyota 86","variant":"GT","year":2016,"list":"www.carlist.my//cars-for-sale/toyota/86/malaysia","position":8},{"name":"2017 Toyota 86 2.0 GT Coupe","id":8187462,"category":"Recon","price":"RM 159,000","brand":"Toyota 86","variant":"GT","year":2017,"list":"www.carlist.my//cars-for-sale/toyota/86/malaysia","position":9}]}});gaPush({'event':'ecommerce_impressions','ecommerce':{impressions:[{"name":"2016 Toyota 86 2.0 Coupe","id":8014839,"category":"Recon","price":"RM 159,000","brand":"Toyota 86","variant":"","year":2016,"list":"www.carlist.my//cars-for-sale/toyota/86/malaysia","position":10},{"name":"2016 Toyota 86 2.0 Coupe","id":8118170,"category":"Recon","price":"RM 165,000","brand":"Toyota 86","variant":"","year":2016,"list":"www.carlist.my//cars-for-sale/toyota/86/malaysia","position":11},{"name":"2017 Toyota 86 2.0 GT Coupe","id":8070347,"category":"Recon","price":"RM 159,000","brand":"Toyota 86","variant":"GT","year":2017,"list":"www.carlist.my//cars-for-sale/toyota/86/malaysia","position":12},{"name":"2016 Toyota 86 2.0 Coupe","id":7877088,"category":"Recon","price":"RM 148,000","brand":"Toyota 86","variant":"","year":2016,"list":"www.carlist.my//cars-for-sale/toyota/86/malaysia","position":13},{"name":"2016 Toyota 86 2.0 Coupe","id":8182562,"category":"Recon","price":"RM 165,000","brand":"Toyota 86","variant":"","year":2016,"list":"www.carlist.my//cars-for-sale/toyota/86/malaysia","position":14},{"name":"2017 Toyota 86 2.0 GT Coupe","id":8085022,"category":"Recon","price":"RM 159,000","brand":"Toyota 86","variant":"GT","year":2017,"list":"www.carlist.my//cars-for-sale/toyota/86/malaysia","position":15},{"name":"2012 Toyota 86 2.0 Coupe","id":7825947,"category":"Used","price":"RM 99,700","brand":"Toyota 86","variant":"","year":2012,"list":"www.carlist.my//cars-for-sale/toyota/86/malaysia","position":16},{"name":"2012 Toyota 86 2.0 GT Coupe","id":7827011,"category":"Used","price":"RM 103,800","brand":"Toyota 86","variant":"GT","year":2012,"list":"www.carlist.my//cars-for-sale/toyota/86/malaysia","position":17},{"name":"2018 Toyota 86 2.0 GT Coupe","id":7500805,"category":"Recon","price":"RM 173,800","brand":"Toyota 86","variant":"GT","year":2018,"list":"www.carlist.my//cars-for-sale/toyota/86/malaysia","position":18},{"name":"2018 Toyota 86 2.0 GT Coupe","id":8100117,"category":"Recon","price":"RM 169,800","brand":"Toyota 86","variant":"GT","year":2018,"list":"www.carlist.my//cars-for-sale/toyota/86/malaysia","position":19}]}});gaPush({'event':'ecommerce_impressions','ecommerce':{impressions:[{"name":"2016 Toyota 86 2.0 GT Coupe","id":8147376,"category":"Recon","price":"RM 153,000","brand":"Toyota 86","variant":"GT","year":2016,"list":"www.carlist.my//cars-for-sale/toyota/86/malaysia","position":20},{"name":"2019 Toyota 86 2.0 GT Coupe","id":8110907,"category":"Recon","price":"RM 194,000","brand":"Toyota 86","variant":"GT","year":2019,"list":"www.carlist.my//cars-for-sale/toyota/86/malaysia","position":21},{"name":"2016 Toyota 86 2.0 Coupe","id":8014425,"category":"Recon","price":"RM 159,000","brand":"Toyota 86","variant":"","year":2016,"list":"www.carlist.my//cars-for-sale/toyota/86/malaysia","position":22},{"name":"2016 Toyota 86 2.0 Coupe","id":8063708,"category":"Recon","price":"RM 159,000","brand":"Toyota 86","variant":"","year":2016,"list":"www.carlist.my//cars-for-sale/toyota/86/malaysia","position":23},{"name":"2017 Toyota 86 2.0 Coupe","id":7363507,"category":"Recon","price":"RM 160,000","brand":"Toyota 86","variant":"","year":2017,"list":"www.carlist.my//cars-for-sale/toyota/86/malaysia","position":24}]}});if(window.iCarAsiaParameters)--}}
        {{--window.iCarAsiaParameters.ajaxifyError='No record found matching your search criteria. Please <a href="javascript:window.location.reload()">click here</a> to refresh the page.</div>';window.facebookLive={};window.facebookLive.wssdomain='connect.carlist.my/';window.facebookLive.locale='en-MY';--}}

    {{--window.params.contactLanguage={"Please enter message or select check box questions.":"Please enter message or select check box questions.","Your message is too short.":"Your message is too short.","Send Message":"Send Message","Sending Message...":"Sending Message...","Continue to Message":"Continue to Message"};--}}

    {{--window.tracking={params:{"make":"toyota","model":"86","vehicle_type":"car","badge_operator":"OR","boss":true,"page_size":25,"facets_all":true,"page_number":1}};--}}

    {{--window.params.authLanguage={"Home":"Home","Profile":"Profile","Saved cars":"Saved cars","Sell your car":"Sell your car","Create Ad":"Create Ad","Log Out":"Log Out","Welcome back":"Welcome back"};window.googlePlusClientId='811961569148-9hnjl7ogeibms8jvgnipvb735m9mj0tn';--}}

    {{--window.onload=function(){if(window.iCarAsiaParameters)--}}
    {{--{window.iCarAsiaParameters.currencyCode='RM';window.iCarAsiaParameters.currencyPrefix=true;}}</script>--}}


<br>
@endsection

@section('script')
    <script>


        $(".vart").click(function(){
            $('.smenu_varients').toggleClass("smenu__filter--show-myself");

            $('.model_menus_varients').removeClass("smenu__filter--show-myself");
            $('.detail_menus_varients').removeClass("smenu__filter--show-myself");
            $('.year_menus_varients').removeClass("smenu__filter--show-myself");
            $('.type_menus_varients').removeClass("smenu__filter--show-myself");
        });
        $(".vartModels").click(function(){
            $('.model_menus_varients').toggleClass("smenu__filter--show-myself");
            $('.smenu_varients').removeClass("smenu__filter--show-myself");
            $('.detail_menus_varients').removeClass("smenu__filter--show-myself");
            $('.year_menus_varients').removeClass("smenu__filter--show-myself");
            $('.type_menus_varients').removeClass("smenu__filter--show-myself");
        });
        $(".vartDetails").click(function(){
            $('.detail_menus_varients').toggleClass("smenu__filter--show-myself");

            $('.smenu_varients').removeClass("smenu__filter--show-myself");
            $('.model_menus_varients').removeClass("smenu__filter--show-myself");
            $('.year_menus_varients').removeClass("smenu__filter--show-myself");
            $('.type_menus_varients').removeClass("smenu__filter--show-myself");
        });
        $(".vartYears").click(function(){
            $('.year_menus_varients').toggleClass("smenu__filter--show-myself");
            $('.detail_menus_varients').removeClass("smenu__filter--show-myself");
            $('.smenu_varients').removeClass("smenu__filter--show-myself");
            $('.model_menus_varients').removeClass("smenu__filter--show-myself");
            $('.type_menus_varients').removeClass("smenu__filter--show-myself");
        });
        $(".vartTypes").click(function(){
            $('.type_menus_varients').toggleClass("smenu__filter--show-myself");
            $('.year_menus_varients').removeClass("smenu__filter--show-myself");
            $('.detail_menus_varients').removeClass("smenu__filter--show-myself");
            $('.smenu_varients').removeClass("smenu__filter--show-myself");
            $('.model_menus_varients').removeClass("smenu__filter--show-myself");
        });
    </script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>


    <script>
        jQuery("#searchBrandFilter").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            jQuery(".brands_filter *").filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });
        jQuery("#searchModelFilter").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            jQuery(".models_filter *").filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });
        jQuery("#searchDetailsFilter").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            jQuery(".details_filter *").filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });
        jQuery("#searchYearsFilter").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            jQuery(".years_filter *").filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });
        jQuery("#searchTypesFilter").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            jQuery(".types_filter *").filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });
    </script>
@endsection